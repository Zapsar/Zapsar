<?php
function getQuestionStats(){
include("creds.php");
$con1=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con1->connect_error){
return "NA";
}
else{
//echo "connection successful";
$rs=mysqli_query($con1,"select count(qid) as 'count' from questions_table;");
$data=mysqli_fetch_array($rs,MYSQLI_ASSOC);
$count=$data["count"];
mysqli_close($con1);
return $count;

}
}

function getAnswerStats(){
include("creds.php");
$con2=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con2->connect_error){
return "NA";
}
else{
//echo "connection successful";
$rs=mysqli_query($con2,"select count(aid) as 'count' from answer_table;");
$data=mysqli_fetch_array($rs,MYSQLI_ASSOC);
$count=$data["count"];
mysqli_close($con2);
return $count;
}
}

function getUserQuestionStats(){
include("creds.php");
$con1=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con1->connect_error){
return "NA";
}
else{
$rs=mysqli_query($con1,"select count(qid) as 'count' from questions_table where username='".$_SESSION["auth_uname"]."';");
$data=mysqli_fetch_array($rs,MYSQLI_ASSOC);
$count=$data["count"];
mysqli_close($con1);
return $count;
}
}

function getUserAnswerStats(){
include("creds.php");
$con2=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con2->connect_error){
return "NA";
}
else{
$rs=mysqli_query($con2,"select count(aid) as 'count' from answer_table where username='".$_SESSION["auth_uname"]."';");
$data=mysqli_fetch_array($rs,MYSQLI_ASSOC);
$count=$data["count"];
mysqli_close($con2);
return $count;
}
}

function getUserFavQuestionStats(){
include("creds.php");
$con1=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con1->connect_error){
return "NA";
}
else{
$rs=mysqli_query($con1,"select count(*) as 'count' from user_fav_question where username='".$_SESSION["auth_uname"]."';");
$data=mysqli_fetch_array($rs,MYSQLI_ASSOC);
$count=$data["count"];
mysqli_close($con1);
return $count;
}
}

function getViewsCount($qid){
include("creds.php");
$con3=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con3->connect_error){
return 0;
}
else{
//echo "connection successful";
if(mysqli_query($con3,"update questions_table set views=views+1 where qid='".$qid."';")){
$res=mysqli_query($con3,"select views from questions_table where qid='".$qid."';");
$data=mysqli_fetch_array($res,MYSQLI_ASSOC);
$count=$data["views"];
mysqli_close($con3);
return $count;
}
}
}

function getLikesCount($qid){
include("creds.php");
error_reporting(E_ALL & ~E_NOTICE);

$con3=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con3->connect_error){
return 0;
}
else{
//echo "connection successful";
$res1=mysqli_query($con3,"select status from questions_like where qid='".$qid."';");
if(mysqli_num_rows($res1)>0){
$arr=array();
$i=0;
while($data1=mysqli_fetch_array($res1,MYSQLI_ASSOC)){
$arr[$i]=$data1["status"];
$i++;
}
$count_status=array_count_values($arr);
$count=$count_status['l']-$count_status['d'];
mysqli_close($con3);
return $count;
}else{
return 0;
}
}
}

function getAnsLikesCount($aid){
include("creds.php");
error_reporting(E_ALL & ~E_NOTICE);

$con3=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con3->connect_error){
return 0;
}
else{
//echo "connection successful";
$res1=mysqli_query($con3,"select status from answer_like where aid='".$aid."';");
if(mysqli_num_rows($res1)>0){
$arr=array();
$i=0;
while($data1=mysqli_fetch_array($res1,MYSQLI_ASSOC)){
$arr[$i]=$data1["status"];
$i++;
}
$count_status=array_count_values($arr);
$count=$count_status['l']-$count_status['d'];
mysqli_close($con3);
return $count;
}else{
return 0;
}
}
}

function getQuesPostTime($post_datetime){
include("creds.php");
$con4=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con4->connect_error){
return "NA";
}
else{
$rs=mysqli_query($con4,"select CONCAT(CURRENT_DATE,' ',CURRENT_TIME) as 'datetime';");
$data=mysqli_fetch_array($rs,MYSQLI_ASSOC);
$curr_datetime=$data["datetime"];

$diff=date_diff(date_create($post_datetime),date_create($curr_datetime));
$diff_str=$diff->format("%y,%m,%d,%h,%i,%s");
$arr=explode(",",$diff_str);
if($arr[0]=="0"){
if($arr[1]=="0"){
if($arr[2]=="0"){
if($arr[3]=="0"){
if($arr[4]=="0"){
return $arr[5]." secs ago";
}else{
return $arr[4]." minutes ago";
}
}else{
return $arr[3]." hour ago";
}
}else{
return $arr[2]." day ago";
}
}else{
return $arr[1]." month ago";
}
}else{
return $arr[0]." year ago";

}
}
}

function getAnsPostDateTime($datetime){
$arr1=explode(" ",$datetime);
$date=$arr1[0];
$time=$arr1[1];

$arr2=explode("-",$date);
$p_year=$arr2[0];
$p_month=$arr2[1];
$p_day=$arr2[2];

$arr3=explode(":",$time);
$p_hour=$arr3[0];
$p_min=$arr3[1];
$p_sec=$arr3[2];

switch($p_month){
case 1: $month="January";
	break;
case 2: $month="Feburary";
	break;
case 3: $month="March";
	break;
case 4: $month="April";
	break;
case 5: $month="May";
	break;
case 6: $month="June";
	break;
case 7: $month="July";
	break;
case 8: $month="August";
	break;
case 9: $month="September";
	break;
case 10: $month="October";
	break;
case 11: $month="November";
	break;
case 12: $month="December";
	break;
}

if($p_hour>12){
$hour=$p_hour-12;
$format="pm";
}else if($p_hour==0){
$hour=$p_hour+12;
$format="am";
}else if($p_hour==12){
$hour=$p_hour;
$format="pm";
}else{
$hour=$p_hour;
$format="am";
}

return $month." ".$p_day." , ".$p_year." at ".$hour.":".$p_min." ".$format;


}

function getRegDate($datetime){
$arr1=explode(" ",$datetime);
$date=$arr1[0];

$arr2=explode("-",$date);
$p_year=$arr2[0];
$p_month=$arr2[1];
$p_day=$arr2[2];

switch($p_month){
case 1: $month="Jan";
	break;
case 2: $month="Feb";
	break;
case 3: $month="Mar";
	break;
case 4: $month="Apr";
	break;
case 5: $month="May";
	break;
case 6: $month="Jun";
	break;
case 7: $month="Jul";
	break;
case 8: $month="Aug";
	break;
case 9: $month="Sep";
	break;
case 10: $month="Oct";
	break;
case 11: $month="Nov";
	break;
case 12: $month="Dec";
	break;
}

return $month." ".$p_day.", ".$p_year;


}

function getFavQuestionStatus($qid){
include("creds.php");
$con1=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con1->connect_error){
return 'n';
}
else{
$res1=mysqli_query($con1,"select count(*) as 'count' from user_fav_question where username='".$_SESSION["auth_uname"]."' and qid='".$qid."';");
$cdata=mysqli_fetch_array($res1,MYSQLI_ASSOC);
if($cdata["count"]>0){
mysqli_close($con1);
return 'y';
}else{
mysqli_close($con1);
return 'n';
}
}
}

function getQuestionLikeStatus($qid){
include("creds.php");
$con1=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con1->connect_error){
return 'none';
}
else{
$res1=mysqli_query($con1,"select status from questions_like where username='".$_SESSION["auth_uname"]."' and qid='".$qid."';");
if(mysqli_num_rows($res1)>0){
$cdata=mysqli_fetch_array($res1,MYSQLI_ASSOC);
$status=$cdata["status"];
mysqli_close($con1);
return $status;
}else{
mysqli_close($con1);
return 'none';
}
}
}

function getAnswerLikeStatus($aid){
include("creds.php");
$con1=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con1->connect_error){
return 'none';
}
else{
$res1=mysqli_query($con1,"select status from answer_like where username='".$_SESSION["auth_uname"]."' and aid='".$aid."';");
if(mysqli_num_rows($res1)>0){
$cdata=mysqli_fetch_array($res1,MYSQLI_ASSOC);
$status=$cdata["status"];
mysqli_close($con1);
return $status;
}else{
mysqli_close($con1);
return 'none';
}
}
}

function getUserPoints($uname){
include("creds.php");
$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
?>
<script type="text/javascript">
alert("We're having some problem with our servers.");
</script>
<?php
}
else{
$userQuesLikes=0;
$userQuesDislikes=0;
$rs=mysqli_query($con,"select qid from questions_table where username='".$uname."';");
if(mysqli_num_rows($rs)>0){
$qid_arr=array();
$i=0;
while($data=mysqli_fetch_array($rs,MYSQLI_ASSOC)){
$qid_arr[$i]=$data["qid"];
$i++;
}
foreach($qid_arr as $qid){
$lres=mysqli_query($con,"select count(status) as 'likes' from questions_like where qid='".$qid."' and status='l';");
$ldata=mysqli_fetch_array($lres,MYSQLI_ASSOC);
$a=$ldata["likes"];
$userQuesLikes+=$a;

$dres=mysqli_query($con,"select count(status) as 'dislikes' from questions_like where qid='".$qid."' and status='d';");
$ddata=mysqli_fetch_array($dres,MYSQLI_ASSOC);
$b=$ddata["dislikes"];
$userQuesDislikes+=$b;

}
}

$userAnsLikes=0;
$userAnsDislikes=0;
$rs=mysqli_query($con,"select aid,post_date,qid from answer_table where username='".$uname."';");
if(mysqli_num_rows($rs)>0){
$aid_arr=array();
$qid_arr=array();
$apost_date=array();
$i=0;
while($data=mysqli_fetch_array($rs,MYSQLI_ASSOC)){
$aid_arr[$i]=$data["aid"];
$qid_arr[$i]=$data["qid"];
$apost_date[$i]=$data["post_date"];
$i++;
}
foreach($aid_arr as $aid){
$lres=mysqli_query($con,"select count(status) as 'likes' from answer_like where aid='".$aid."' and status='l';");
$ldata=mysqli_fetch_array($lres,MYSQLI_ASSOC);
$a=$ldata["likes"];
$userAnsLikes+=$a;

$dres=mysqli_query($con,"select count(status) as 'dislikes' from answer_like where aid='".$aid."' and status='d';");
$ddata=mysqli_fetch_array($dres,MYSQLI_ASSOC);
$b=$ddata["dislikes"];
$userAnsDislikes+=$b;

}
$i=0;
$bonusPoint=0;
$bonusAnsCount=0;
foreach($qid_arr as $qid){
$qres=mysqli_query($con,"select post_date from questions_table where qid='".$qid."';");
$qdata=mysqli_fetch_array($qres,MYSQLI_ASSOC);
$qpost_date=$qdata["post_date"];

$diff=date_diff(date_create($qpost_date),date_create($apost_date[$i]));
$diff_str=$diff->format("%m,%d,%h,%i");
$arr=explode(",",$diff_str);

if($arr[0]=="0"){
if($arr[1]=="0"){
if($arr[2]=="0"){
if($arr[3]<="15"){
$bonusPoint+=25;
$bonusAnsCount++;
//echo "15 min bonus:".$aid_arr[$i];
}else if($arr[3]<="30"){
$bonusPoint+=20;
$bonusAnsCount++;
//echo "30 min bonus:".$aid_arr[$i];
}else if($arr[3]<="59"){
$bonusPoint+=16;
$bonusAnsCount++;
//echo "1 hour bonus:".$aid_arr[$i];
}
}else if($arr[2]<="2"){
$bonusPoint+=12;
$bonusAnsCount++;
//echo "3 hour bonus:".$aid_arr[$i];
}else if($arr[2]<="11"){
$bonusPoint+=8;
$bonusAnsCount++;
//echo "12 hour bonus:".$aid_arr[$i];
}else if($arr[2]<="23" and $arr[3]<="59"){
$bonusPoint+=4;
$bonusAnsCount++;
//echo "1 Day bonus:".$aid_arr[$i];
}
}else if($arr[1]<="14"){
$bonusPoint+=2;
$bonusAnsCount++;
//echo "15 Day bonus:".$aid_arr[$i];
}else if($arr[1]<="31"){
$bonusPoint+=1;
$bonusAnsCount++;
//echo "1 Month bonus:".$aid_arr[$i];
}
}
$i++;

}
}

$rs=mysqli_query($con,"select sum(views) as 'total' from questions_table where username='".$uname."' and views>0;");
$vdata=mysqli_fetch_array($rs,MYSQLI_ASSOC);
$userQuesView=$vdata["total"];

$rs=mysqli_query($con,"select count(*) as 'count' from questions_table where username='".$uname."';");
$qdata=mysqli_fetch_array($rs,MYSQLI_ASSOC);
$userQuesCount=$qdata["count"];

$rs=mysqli_query($con,"select count(*) as 'count' from answer_table where username='".$uname."';");
$adata=mysqli_fetch_array($rs,MYSQLI_ASSOC);
$userAnsCount=$adata["count"];

mysqli_close($con);
}
$userQuesCountPoint=$userQuesCount;
$userAnsCountPoint=$userAnsCount*5;
$userQuesViewPoint=$userQuesView*0.5;
$userQuesLikesPoint=$userQuesLikes - $userQuesDislikes*0.5;
$userAnsLikesPoint=$userAnsLikes*2 - $userAnsDislikes*0.5;
$userPoints=$userQuesCountPoint + $userAnsCountPoint + $userQuesViewPoint + $userQuesLikesPoint + $userAnsLikesPoint + $bonusPoint;
return (int)$userPoints;

}

?>