<?php
include("creds.php");
$tag_filter=$_POST["tag_filter"];
$tag_filter=strtolower($tag_filter);
$prev_tag_filter=$_POST["prev_tag_filter"];

$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
$rs=mysqli_query($con,"select * from questions_table where tag='".$tag_filter."' order by CONVERT(SUBSTR(qid,2),SIGNED INTEGER) desc;");
if(mysqli_num_rows($rs)>0){
echo '<form id="form1" action="cat_question.php" method="post">
<input type="hidden" name="tag_filter" value="'.$tag_filter.'">
<input type="hidden" name="is_custom_tag" value="false">
</form>';
?>
<script type="text/javascript">
document.getElementById("form1").submit();
</script>
<?php
}else{
echo '<form id="form1" action="cat_question.php" method="post">
<input type="hidden" name="tag_filter" value="'.$prev_tag_filter.'">
<input type="hidden" name="is_custom_tag" value="false">
</form>';
?>
<script type="text/javascript">
document.getElementById("form1").submit();
alert("No questions found with this tag.");
</script>
<?php

}
?>
