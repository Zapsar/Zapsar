<?php
include("creds.php");

session_start();

$username=$_POST["author"];
$email=$_POST["email"];
$answer=$_POST["comment"];
$qid=$_POST["single_ques_id"];

if($username==""||$email==""||$answer==""){
?>
<script type="text/javascript">
//location.href="single_question.php";
window.history.back();
alert("You left some fields empty.");
</script>
<?php
}else{
$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
?>
<script type="text/javascript">
location.href="single_question.php";
alert("We're having some problem with our servers.");
</script>
<?php
}
else{
$answer=mysqli_real_escape_string($con,$answer);

$auth1=mysqli_query($con,"select email from user_creds where username='".$username."';");
if(mysqli_num_rows($auth1)>0){
$data_auth1=mysqli_fetch_array($auth1,MYSQLI_ASSOC);
if($data_auth1["email"]==$email){

if(mysqli_query($con,"insert into aids values(null);")){
$aid="";
$res=mysqli_query($con,"select aid from aids order by aid DESC limit 1;");
$data=mysqli_fetch_array($res,MYSQLI_ASSOC);
$aid=$data["aid"];

if(mysqli_query($con,"insert into answer_table values(null,'".$username."',CONCAT('A','".$aid."'),'".$qid."','".$answer."',CONCAT(CURRENT_DATE,' ',CURRENT_TIME));")){
if(mysqli_query($con,"update questions_table set status='s' where qid='".$qid."';")){
$res=mysqli_query($con,"select * from questions_table where qid='".$qid."';");
$data=mysqli_fetch_array($res,MYSQLI_ASSOC);

$qid=$data["qid"];
$title=$data["title"];
$details=$data["details"];
$custom_tags=$data["custom_tags"];
$tag=$data["tag"];
$author=$data["username"];
$post_date=$data["post_date"];
$status='s';
$views=$data["views"];

$rs=mysqli_query($con,"select count('".$qid."') as 'count' from answer_table where qid='".$qid."';");
$data=mysqli_fetch_array($rs,MYSQLI_ASSOC);
$answers=$data["count"];

$pres=mysqli_query($con,"select photo from user_profile where username='".$author."';");
if(mysqli_num_rows($pres)>0){
$pdata=mysqli_fetch_array($pres,MYSQLI_ASSOC);
$picture=$pdata["photo"];
}else{
$picture="avatar.png";
}
if($picture==""){
$picture="avatar.png";
}

mysqli_close($con);

?>
<html>
<body>
<form action="single_question.php" method="post" id="post_answer_form">
<input type="hidden" name="single_ques_title" value="<?php echo $title;?>">
<input type="hidden" name="single_ques_id" value="<?php echo $qid;?>">
<input type="hidden" name="single_ques_details" value="<?php echo $details;?>">
<input type="hidden" name="single_ques_author" value="<?php echo $author;?>">
<input type="hidden" name="single_ques_status" value="<?php echo $status;?>">
<input type="hidden" name="single_ques_answers" value="<?php echo $answers;?>">
<input type="hidden" name="single_ques_custom_tags" value="<?php echo $custom_tags;?>">
<input type="hidden" name="single_ques_tag" value="<?php echo $tag;?>">
<input type="hidden" name="single_ques_picture" value="<?php echo $picture;?>">
<input type="hidden" name="single_ques_post_date" value="<?php echo $post_date;?>">
</form>
<script type="text/javascript">
document.getElementById("post_answer_form").submit();
alert("AWESOME!, Your answer posted successfully.");
</script>
</body>
</html>

<?php
}else{
redirect($con);
}
}else{
redirect($con);
}
}
else{
redirect($con);
}
}else{
redirect($con);
}
}else{
redirect($con);
}
}
}

function redirect($con){
mysqli_close($con);
?>
<script type="text/javascript">
window.history.back();
alert("SORRY, not able to publish your question. Please Try again...");
</script>
<?php
}
?>
