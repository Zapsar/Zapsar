SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


-- --------------------------------------------------------

--
-- Table structure for table `aids`
--

CREATE TABLE IF NOT EXISTS `aids` (
  `aid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'answer id',
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='distributes answer ids' AUTO_INCREMENT=18;

INSERT INTO `aids` values
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16),
(17);

-- --------------------------------------------------------

--
-- Table structure for table `answer_like`
--

CREATE TABLE IF NOT EXISTS `answer_like` (
  `username` varchar(50) NOT NULL,
  `aid` varchar(50) NOT NULL,
  `status` char(1) NOT NULL COMMENT 'l is like, d is dislike',
  PRIMARY KEY (`username`,`aid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='stores answer''s likes';

--
-- Dumping data for table `answer_like`
--

-- --------------------------------------------------------

--
-- Table structure for table `answer_table`
--

CREATE TABLE IF NOT EXISTS `answer_table` (
  `sno` int(11) NOT NULL AUTO_INCREMENT COMMENT 'auto incremented serial number',
  `username` varchar(50) NOT NULL COMMENT 'user name should be unique',
  `aid` varchar(50) NOT NULL COMMENT 'answer id',
  `qid` varchar(50) NOT NULL COMMENT 'question id',
  `answer` text NOT NULL COMMENT 'answer text',
  `post_date` datetime NOT NULL COMMENT 'answer posting date time',
  PRIMARY KEY (`aid`),
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='answers table' AUTO_INCREMENT=18;

--
-- Dumping data for table `answer_table`
--

INSERT INTO `answer_table` (`sno`, `username`, `aid`, `qid`, `answer`, `post_date`) VALUES
(1, 'abhi', 'A1', 'Q4', 'Somehow they all are same, but the difference comes in the duration. MTech requires 2 years and syllabus based on advance computer science focused mostly on industry. MTech RA or MS both are same but institute use any one terms, it requires 2 or 3 years, but mostly 3 years, relaxed syllabus and focused on practical and research, students can write their own thesis. Now PhD spanned over 5 years, it needs more depth understanding of the subject and must require thesis. Placement wise MTech and MS both are same, but sometimes MS students are given more preference for RND works over MTech guys. After PhD mostly become professor.', '2017-06-17 10:02:45'),
(2, 'abhi', 'A2', 'Q4', 'Mtech guys receive 12400 stipend for working 6 to 8 hours each week. Same applies for MS but they receive 12500. Phd guys receive 12500 for first year and then 25000 afterward. In top IITs Mtech students have same opportunity for placements as Btech students, but definitely there gonna be tough competition. Some institute do not allow Mtech guys for IT companies where Btech guys are allowed.', '2017-06-17 11:05:06'),
(3, 'abhi', 'A3', 'Q3', 'Database is collection of raw data. Some database represent it in the form of rows and column, other represent as objects stored in files. DBMS is database management system, it manages everything related to database like storing data, fetching them, arranging them, optimizing them, deleting them, etc. It understand structured query language SQL, that tells DBMS to perform these tasks. There are \n1. relational databases\n2. document oriented databases\n3. object oriented databases\nPopular DBMS are: MySQL, Oracle, MongoDB, Elephant, SQL Server, DB2, etc.', '2017-06-17 11:16:55'),
(4, 'abhi', 'A4', 'Q2', 'In windows: open command prompt or windows prompt, type DISKPART -> LIST DISK -> SELECT DISK <x> -> CLEAN -> CREATE PART PRI -> SELECT PART 1 -> FS=NTFS QUICK -> ACTIVE -> EXIT -> copy the content of iso file to the bootable disk and you are ready.', '2017-06-17 11:21:52'),
(5, 'abhi', 'A5', 'Q7', 'Above 900 you''ll definitely get a direct admission in top IITs as per CSE. Above 700 you might get a admission interview call letter. Below 650, the chances are very low. Its a saying that top IITs take students with AIR < 500. But with recent trends they might go upto AIR <1000.  ', '2017-06-17 11:27:04'),
(6, 'abhi', 'A6', 'Q10', 'Go through Android Docs of Google, there you will find everything about how to work with bluetooth. Link is www.developer.android.com', '2017-06-17 12:36:43'),
(7, 'abhi', 'A7', 'Q7', 'For MTech AIR < 500 you will get direct admission in IISc, IIT Delhi, IIT Bombay, IIT Kanpur, IIT Madras. With AIR<1000 you may get an interview call letter. For MS AIR<1200 you will get writter or interview or both call letter. For MS admission there is no direct admission, you have to go through interview or written test. For Phd, you can get direct admission in top IITs.  ', '2017-06-17 13:05:43'),
(8, 'abhi', 'A8', 'Q6', 'Till now ASUS has not issued any official OTA upgrade for Zenfone 5 devices. But whoever wants to upgrade their devices to Lollipop they can visit ASUS website and look for firmware for androids. Download the latest version of lollipop firmware that must match the initial release characters like WW, CU, CHU, etc. How to install steps are also given there. These upgrades might not be stable and you would not receive any OTA update after that too.', '2017-06-17 14:53:49'),
(9, 'abhi', 'A9', 'Q10', 'To start with, there are getting started guide within training link on developer.android.com for bluetooth. To get into advance visit apis guides and references.', '2017-06-17 15:13:25'),
(10, 'abhi', 'A10', 'Q8', 'splitting a string in php is quite simple, use explode(<delimiter>,<string>) function. Use array variable to store the splitted string. \r\nExample: $arr=explode(" ","Hello welcome to PHP ");', '2017-06-19 10:50:31'),
(11, 'alex', 'A11', 'Q9', 'In situation where data is huge and its attributes are varying. If you store using relational databases you will unnecessary waste space. Then document oriented and object oriented database come into play. They are easily expandable and are somewhat similarly efficient as relational database. When you know your data will have these specified attributes and its not gonna change throughout its lifetime, you must use relational databases, cause in this case they are more efficient than other and don not waste any spaces.  ', '2017-06-19 13:47:12'),
(12, 'alex', 'A12', 'Q8', 'explode function use first parameter as a delimiter that will split the string, and second parameter as string itself, it returns an array. Example: $str=explode("-","2017-06-17"); here - is delimiter and 2017-06-17 is the string. $str array will contain $str[0] is 2017, $str[1] is 06, and $str[2] is 17', '2017-06-19 13:55:53'),
(13, 'abhi', 'A13', 'Q11', 'visit w3school site there you will find thorough details about how to upload file to server using php', '2017-06-20 20:22:27'),
(14, 'emily', 'A14', 'Q11', 'you have to give directory name, file name. check weather the file is the desired file, of desired format and within the size. pathinfo($targetfile, PATHINFO_EXTENSION) returns extension of file, use $_FILES["file"]["size"] to get the size and finally to upload the file use move_uploaded_file($local_file,$server_file)', '2017-06-20 20:30:03'),
(15, 'emily', 'A15', 'Q13', 'Use mysql function AES_ENCRYPT(plaintext,key) for encryption, to decrypt use AES_DECRYPT(cipher,plaintext). MySQL also has DES_ENCRYPT, DES_DECRYPT function', '2017-06-21 09:26:21'),
(16, 'emily', 'A16', 'Q1', 'There are lots of generations of Intel processors. Like:\r\nIntel Atom\r\nIntel Pentium\r\nIntel i3, i5, i7 series\r\nIntel Xeon\r\nand others\r\nThey all are different based on the performance, cost, processors cores, power consumption and other variables.\r\nFor PCs Intel ith generation familiies are recommended. Right now the latest generation is 7th, but in marketplace 6th gen are available.\r\nPerformance wise:\r\nAtom< Pentium< i3< i5< i7< Xeon\r\ni3 contains only 2 cores, i5 contains 2 or 4 cores and i7 contains 4 or 8 cores and they are very powerful.\r\nSame goes to generation:\r\n1st< 2nd< 3rd< 4th< 5th< 6th< 7th\r\n\r\nYou can find more detail at Intel''s official website', '2017-06-21 15:47:58'),
(17, 'emily', 'A17', 'Q14', 'use implode(<delimiter>,<string array>) it returns a string\r\nExample:\r\n$array=[0=>''''This",1=>"is",2=>"php",3=>"admin"];\r\n$str=implode(" ",$array);\r\necho $str;\r\nOutput: This is php admin', '2017-06-22 09:16:45');

-- --------------------------------------------------------

--
-- Table structure for table `pid`
--

CREATE TABLE IF NOT EXISTS `pid` (
  `sno` int(11) NOT NULL AUTO_INCREMENT COMMENT 'picture ids',
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 ;

-- --------------------------------------------------------

--
-- Table structure for table `qids`
--

CREATE TABLE IF NOT EXISTS `qids` (
  `qid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'question ids',
  PRIMARY KEY (`qid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `qids`
--

INSERT INTO `qids` (`qid`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12),
(13),
(14);

-- --------------------------------------------------------

--
-- Table structure for table `questions_like`
--

CREATE TABLE IF NOT EXISTS `questions_like` (
  `username` varchar(50) NOT NULL,
  `qid` varchar(50) NOT NULL,
  `status` char(1) NOT NULL COMMENT 'l for like, d for dislike',
  PRIMARY KEY (`username`,`qid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='stores question''s likes count';


-- --------------------------------------------------------

--
-- Table structure for table `questions_table`
--

CREATE TABLE IF NOT EXISTS `questions_table` (
  `sno` int(11) NOT NULL AUTO_INCREMENT COMMENT 'auto incremented serial number',
  `username` varchar(50) NOT NULL COMMENT 'user name should be unique',
  `qid` varchar(50) NOT NULL COMMENT 'question id',
  `title` text NOT NULL COMMENT 'question title',
  `tag` varchar(50) NOT NULL,
  `custom_tags` text NOT NULL COMMENT 'tags, multiple tags are separated by comma',
  `details` text NOT NULL COMMENT 'question details',
  `status` char(1) NOT NULL DEFAULT 'i' COMMENT 'status, s for solved, i for in progress',
  `views` int(11) NOT NULL DEFAULT '0' COMMENT 'views of question',
  `post_date` datetime NOT NULL COMMENT 'question posting date time',
  PRIMARY KEY (`qid`),
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='question table' AUTO_INCREMENT=15 ;

--
-- Dumping data for table `questions_table`
--

INSERT INTO `questions_table` (`sno`, `username`, `qid`, `title`, `tag`, `custom_tags`, `details`, `status`, `views`, `post_date`) VALUES
(1, 'abhi', 'Q1', 'CPU Generations', 'technology', 'computer, cpu, intel generations', 'What are the families of Intel Processors and How they are different from each other. How to identify them all.', 's', 18, '2017-04-30 15:41:00'),
(2, 'abhi', 'Q2', 'Bootable Drive', 'computer', 'boot,os', 'How to create bootable derive for Linux and Windows Computer. ', 's', 23, '2017-04-30 15:55:33'),
(3, 'abhi', 'Q3', 'DBMS', 'database', 'software', 'What is Database and DBMS? What are different types of DBMS and databses.', 's', 11, '2017-04-30 16:04:10'),
(4, 'abhi', 'Q4', 'Postgraduate', 'admission', 'mtech,ms,phd', 'Difference between Mtech, MS and Phd. Are they same, if different how. What is best to pursue after Btech. ', 's', 34, '2017-05-22 13:07:06'),
(5, 'abhi', 'Q5', 'Amazon Beanstalk Pricing', 'cloud', 'amazon aws,computing platform', 'Whats is the pricing of AWS Beanstalk. What languages does it support.', 'i', 30, '2017-06-13 17:18:05'),
(6, 'abhi', 'Q6', 'ASUS Zenfone Lollipop Upgrade', 'smartphones', 'asus zenfone 5', 'Does ASUS issued any official Lollipop firmware update for Zenfone 5 models.', 's', 18, '2017-06-13 17:33:54'),
(7, 'abhi', 'Q7', 'Minimum Gate Score to get admission in IIT', 'admission', 'mtech', 'What is the minimum score required to get an admission in top IITs. Do they consider rank too. If yes then what should be the minimum rank.', 's', 25, '2017-06-13 17:40:06'),
(8, 'abhi', 'Q8', 'separate a string in PHP', 'programming', 'php,strings', 'How to separate a string into separate words.\r\nWhat to use to store these separated words Array, List or Objects.', 's', 33, '2017-06-17 08:41:15'),
(9, 'abhi', 'Q9', 'Working with Database', 'database', 'mysql', 'What database to use for unknown attributes, unknown database size. Where MySQL benefits from other databases. What are Object Oriented Databases and Document Oriented Databases.', 's', 28, '2017-06-17 08:47:27'),
(10, 'abhi', 'Q10', 'Working with Bluetooth in Android', 'android', 'bluetooth', 'How to work with bluetooth in Android. Are there any libraries for energy efficiency. Can bluetooth connect simultaneously with more than one senders.', 's', 95, '2017-06-17 08:55:28'),
(11, 'alex', 'Q11', 'upload file to server using php', 'programming', 'file upload,php', 'How to upload a file to a web server using php. How to check if the uploaded file has the desired format.', 's', 37, '2017-06-19 14:00:19'),
(12, 'emily', 'Q12', 'create a mailing code using php', 'programming', 'php,email', 'Create a mailing system that send users emails without using any mailing agent. Just take user name, email, subject and message, no need to visit gmail or any other mailing site.', 'i', 49, '2017-06-19 15:32:56'),
(13, 'alex', 'Q13', 'Use AES ENCRYPTION in MySQL', 'database', 'aes encryption,mysql', 'How to encrypt a plaintext using aes encryption. How to decrypt it. Is there any encryption techniques other than aes supported by MySQL.', 's', 58, '2017-06-21 08:00:25'),
(14, 'abhi', 'Q14', 'Construct a string from array in php', 'programming', 'php,array,string', 'How to construct a string from an array in php.', 's', 17, '2017-06-22 08:58:41');

-- --------------------------------------------------------

--
-- Table structure for table `user_creds`
--

CREATE TABLE IF NOT EXISTS `user_creds` (
  `sno` int(11) NOT NULL AUTO_INCREMENT COMMENT 'auto incremented serial number',
  `username` varchar(50) NOT NULL COMMENT 'user name should be unique',
  `email` varchar(100) NOT NULL COMMENT 'email id',
  `pswd` varchar(100) NOT NULL COMMENT 'password',
  `reg_date` datetime NOT NULL COMMENT 'registration date time',
  PRIMARY KEY (`username`),
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='user credential table' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user_creds`
--

INSERT INTO `user_creds` (`sno`, `username`, `email`, `pswd`, `reg_date`) VALUES
(1, 'abhi', 'abhijeet.jeet07@gmail.com', 'Ûåçü`ÔlàMèà6Qâ4×', '2017-04-28 16:09:10'),
(2, 'alex', 'alexsmith@gmail.com', '6W?PI\0ÿãñÒè£u', '2017-06-19 13:39:20'),
(3, 'emily', 'emily@gmail.com', '6W?PI\0ÿãñÒè£u', '2017-06-19 14:36:08');

-- --------------------------------------------------------

--
-- Table structure for table `user_fav_question`
--

CREATE TABLE IF NOT EXISTS `user_fav_question` (
  `username` varchar(50) NOT NULL,
  `qid` varchar(50) NOT NULL,
  PRIMARY KEY (`username`,`qid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='stores user''s favorite questions list';

-- --------------------------------------------------------

--
-- Table structure for table `user_points`
--

CREATE TABLE IF NOT EXISTS `user_points` (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `points` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`username`),
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='stores user points' ;

-- --------------------------------------------------------

--
-- Table structure for table `user_profile`
--

CREATE TABLE IF NOT EXISTS `user_profile` (
  `sno` int(11) NOT NULL AUTO_INCREMENT COMMENT 'auto incremented serial number',
  `username` varchar(50) NOT NULL COMMENT 'user name should be unique',
  `fname` varchar(100) DEFAULT 'NA' COMMENT 'first name',
  `lname` varchar(100) DEFAULT 'NA' COMMENT 'last name',
  `photo` varchar(100) DEFAULT 'NA' COMMENT 'profile photo',
  `country` varchar(50) DEFAULT 'India' COMMENT 'country',
  `website` varchar(150) DEFAULT 'NA' COMMENT 'website link',
  `about` text COMMENT 'about me',
  `googleplus` varchar(100) DEFAULT 'NA' COMMENT 'google plus account link',
  `facebook` varchar(100) DEFAULT 'NA' COMMENT 'facebook profile link',
  `twitter` varchar(100) DEFAULT 'NA' COMMENT 'twitter profile link',
  `linkedin` varchar(100) DEFAULT 'NA' COMMENT 'linked profile link',
  `last_updated` datetime NOT NULL COMMENT 'last updated profile date time',
  PRIMARY KEY (`username`),
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='user profile data is stores here, this table may contain nulls' ;

