<?php
include("creds.php");

session_start();

$uname=$_SESSION["auth_uname"];
$title=$_POST["question_title"];
$custom_tags=$_POST["question_custom_tags"];
$tag=$_POST["question_tag"];
$details=$_POST["question_details"];

if($title==""||$tag==""||$details==""){
?>
<script type="text/javascript">
window.history.back();
alert("These are required fields, you cannot leave them empty.");
</script>
<?php
}else{
$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
?>
<script type="text/javascript">
window.history.back();
alert("We're having some problem with our servers.");
</script>
<?php
}
else{

$title=mysqli_real_escape_string($con,$title);
$details=mysqli_real_escape_string($con,$details);
//echo "connection successful";
$rs=mysqli_query($con,"insert into qids values(null);");
if($rs){
$qid="";
$res=mysqli_query($con,"select qid from qids order by qid DESC limit 1;");
while($data=mysqli_fetch_array($res,MYSQLI_ASSOC)){
$qid=$data["qid"];
}
if($custom_tags!=""){
$custom_tags=strtolower($custom_tags);
$tag_array=explode(",",$custom_tags);//store in array
$unique_tag_array=str_replace($tag,"",$tag_array);//replace primary tag with ""
$unique_custom_tag=array();//form unique custom tag array
$i=0;
foreach($unique_tag_array as $v){
if($v!=""){
$unique_custom_tag[$i]=$v;
$i++;
}
}
$custom_tags=implode(",",$unique_custom_tag);// construct unique custom tag array into custom tag string
}else{
$custom_tags="";
//ucfirst() ucwords()
}
$rs=mysqli_query($con,"insert into questions_table values(null,'".$uname."',CONCAT('Q','".$qid."'),'".$title."','".$tag."','".$custom_tags."','".$details."','i',0,CONCAT(CURRENT_DATE,' ',CURRENT_TIME));");
if($rs){
$dres=mysqli_query($con,"select CONCAT(CURRENT_DATE,' ',CURRENT_TIME) as 'datetime';");
$ddate=mysqli_fetch_array($dres,MYSQLI_ASSOC);
$_SESSION["single_ques_pri_id"]=$qid;
$_SESSION["single_ques_pri_title"]=$title;
$_SESSION["single_ques_pri_details"]=$details;
$_SESSION["single_ques_pri_status"]='i';
$_SESSION["single_ques_pri_views"]=0;
$_SESSION["single_ques_pri_custom_tags"]=$custom_tags;
$_SESSION["single_ques_pri_likes"]=0;
$_SESSION["single_ques_pri_tag"]=$tag;
$_SESSION["single_ques_pri_post_date"]=$ddate["datetime"];
$_SESSION["single_ques_pri_author"]=$uname;
$_SESSION["single_ques_pri_fav"]='n';
$_SESSION["single_ques_pri_picture"]=$_SESSION["user_photo"];
$_SESSION["single_ques_pri_answers"]=0;
?>
<script type="text/javascript">
location.href="single_question_private.php";
alert("GREAT!, Your question publised successfully.");
</script>
<?php
mysqli_close($con);
}else{
?>
<script type="text/javascript">
window.history.back();
alert("SORRY, not able to publish your question. Please Try again...");
</script>
<?php
}
}

}
}



?>