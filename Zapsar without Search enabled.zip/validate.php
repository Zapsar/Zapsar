<?php
include("creds.php");
include("stats.php");
error_reporting(E_ALL & ~E_NOTICE);

$uname=$_POST["uname"];
$pswd=$_POST["pswd"];
if($uname=="Username"||$pswd=="Password"){
?>
<script type="text/javascript">
//location.href="index.php";
window.history.back();
alert("Username or Password filed are empty.");
</script>
<?php
}else{

$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
?>
<script type="text/javascript">
//location.href="index.php";
window.history.back();
alert("We're having some problem with our servers.");
</script>
<?php
}
else{
$rs=mysqli_query($con,"select AES_DECRYPT(pswd,'".$mysql_key."') as 'pswd' from user_creds where username='".$uname."';");
if(mysqli_num_rows($rs)>0){
$data=mysqli_fetch_array($rs,MYSQLI_ASSOC);
if($data["pswd"]==$pswd){

$pres=mysqli_query($con,"select photo from user_profile where username='".$uname."';");
if(mysqli_num_rows($pres)>0){
$pdata=mysqli_fetch_array($pres,MYSQLI_ASSOC);
$picture=$pdata["photo"];
}else{
$picture="avatar.png";
}
if($picture==""){
$picture="avatar.png";
}

session_start();
$_SESSION["auth_uname"]=$uname;
$_SESSION["user_photo"]=$picture;
$_SESSION["user_points"]=getUserPoints($uname);

$rs=mysqli_query($con,"select points from user_points where username='".$uname."';");
if(mysqli_num_rows($rs)>0){
mysqli_query($con,"update user_points set points='".$_SESSION["user_points"]."' where username='".$uname."';");
}else{
mysqli_query($con,"insert into user_points values(null,'".$uname."','".$_SESSION["user_points"]."');");
}

mysqli_close($con);

?>
<script type="text/javascript">
location.href="index_private.php";
</script>
<?php
}else{
mysqli_close($con);
?>
<script type="text/javascript">
window.history.back();
alert("Username or Password incorrect.");
</script>
<?php
}
}else{
mysqli_close($con);
?>
<script type="text/javascript">
window.history.back();
alert("This Username is not registered. Register before logging in.");
</script>
<?php
}
}
}
?>