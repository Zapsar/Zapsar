<?php
include("creds.php");

session_start();
$uname=$_SESSION["auth_uname"];
$curr_pswd=$_POST["curr_pswd"];
$new_pswd=$_POST["new_pswd"];
$confirm_pswd=$_POST["confirm_pswd"];

if($new_pswd==""||$confirm_pswd==""||$curr_pswd==""){
?>
<script type="text/javascript">
window.history.back();
alert("Password fields cannot be empty.");
</script>
<?php
}else{
if($new_pswd==$confirm_pswd){
$con1=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con1->connect_error){
?>
<script type="text/javascript">
window.history.back();
alert("We're having trouble with our servers");
</script>
<?php
}
else{
$new_pswd=mysqli_real_escape_string($con,$new_pswd);


$res1=mysqli_query($con1,"select AES_DECRYPT(pswd,'".$mysql_key."') as 'pswd', pswd as 'en_pswd' from user_creds where username=AES_ENCRYPT('".$uname."','".$mysql_key."');");
$data1=mysqli_fetch_array($res1,MYSQLI_ASSOC);
$pswd1=$data1["pswd"];
$en_pswd1=$data1["en_pswd"];
if($pswd1==$curr_pswd){
if(mysqli_query($con1,"update user_creds set pswd=AES_ENCRYPT('".$new_pswd."','".$mysql_key."') where username=AES_ENCRYPT('".$uname."','".$mysql_key."') and pswd='".$en_pswd1."';")){
mysqli_close($con1);
?>
<script type="text/javascript">
location.href="edit_profile.php";
alert("Password Changed Successfully");
</script>
<?php
}else{
mysqli_close($con1);
?>
<script type="text/javascript">
window.history.back();
alert("Unable to change password. Please Try Again...");
</script>
<?php
}
}else{
mysqli_close($con1);
?>
<script type="text/javascript">
window.history.back();
alert("Your Current Password didn't match. Please Try Again...");
</script>
<?php
}
}
}else{
?>
<script type="text/javascript">
window.history.back();
alert("New Passwords didn't match. Try Again...");
</script>
<?php
}
}
?>