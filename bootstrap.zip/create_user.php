<?php
include("creds.php");
error_reporting(E_ALL & ~E_NOTICE);

$uname=$_POST["uname"];
$email=$_POST["email"];
$pswd=$_POST["pswd"];
$cpswd=$_POST["cpswd"];
if($uname==""||$email==""||$pswd==""||$cpswd==""){
?>
<script type="text/javascript">
window.history.back();
alert("Required fields cannot be empty.");
</script>
<?php
}else{
if($pswd==$cpswd){
$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
?>
<script type="text/javascript">
window.history.back();
alert("We're having some problem with our servers.");
</script>
<?php
}
else{
//echo "connection successful";
$email=strtolower($email);
$uname=mysqli_real_escape_string($con,$uname);
$email=mysqli_real_escape_string($con,$email);
$pswd=mysqli_real_escape_string($con,$pswd);

if(mysqli_query($con,"insert into user_creds values(null,AES_ENCRYPT('".$uname."','".$mysql_key."'),'".$email."',AES_ENCRYPT('".$pswd."','".$mysql_key."'),CONCAT(CURRENT_DATE,' ',CURRENT_TIME));")){

?>
<script type="text/javascript">
location.href="index.php";
alert("New Account Created. Login to access your account.");

</script>
<?php
mysqli_close($con);
}else{
?>
<script type="text/javascript">
window.history.back();
alert("Use different username, it already exists.");
</script>
<?php
}

}
}else{
?>
<script type="text/javascript">
window.history.back();
alert("Passwords are not matching");
</script>
<?php
}
}
?>