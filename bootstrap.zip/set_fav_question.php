<?php
include("creds.php");
include("stats.php");
session_start();
$uname=$_SESSION["auth_uname"];

$fav=$_SESSION["single_ques_pri_fav"];
$qid=$_SESSION["single_ques_pri_id"];

$con1=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con1->connect_error){
?>
<script type="text/javascript">
window.history.back();
alert("Not able to set/unset favorite question, Server not responding");
</script>
<?php
}
else{

if($fav=='y'){
if(mysqli_query($con1,"delete from user_fav_question where username=AES_ENCRYPT('".$uname."','".$mysql_key."') and qid='".$qid."';")){
$_SESSION["single_ques_pri_fav"]='n';
mysqli_close($con1);
?>
<script type="text/javascript">
location.href="single_question_private.php";
alert("Question removed from favorite list.");
</script>
<?php
}else{
$_SESSION["single_ques_pri_fav"]='y';
mysqli_close($con1);
?>
<script type="text/javascript">
location.href="single_question_private.php";
alert("Unable to remove question from favorite list.");
</script>
<?php
}
}else if($fav=='n'){
if(mysqli_query($con1,"insert into user_fav_question values(AES_ENCRYPT('".$uname."','".$mysql_key."'),'".$qid."');")){
$_SESSION["single_ques_pri_fav"]='y';
mysqli_close($con1);
?>
<script type="text/javascript">
location.href="single_question_private.php";
alert("Question added to favorite list.");
</script>
<?php
}else{
$_SESSION["single_ques_pri_fav"]='n';
mysqli_close($con1);
?>
<script type="text/javascript">
location.href="single_question_private.php";
alert("Unable to add Question to favorite list.");
</script>
<?php
}
}
}
?>