<?php
include("creds.php");
include("stats.php");
session_start();
$uname=$_SESSION["auth_uname"];

$aid=$_POST["ans_id_field"];
$status=$_POST["ans_like_field"];

$con1=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con1->connect_error){
?>
<script type="text/javascript">
window.history.back();
alert("Not able to like/dislike this answer, Server not responding");
</script>
<?php
}
else{
$res=mysqli_query($con1,"select * from answer_like where username=AES_ENCRYPT('".$uname."','".$mysql_key."') and aid='".$aid."';");
if(mysqli_num_rows($res)>0){
if(mysqli_query($con1,"update answer_like set status='".$status."' where username=AES_ENCRYPT('".$uname."','".$mysql_key."') and aid='".$aid."';")){
mysqli_close($con1);
?><script type="text/javascript">
location.href="single_question_private.php";
</script>
<?php
}else{
mysqli_close($con1);
?><script type="text/javascript">
window.history.back();
alert("Unable to like/dislike this Answer");
</script>
<?php
}
}else{
if(mysqli_query($con1,"insert into answer_like values(AES_ENCRYPT('".$uname."','".$mysql_key."'),'".$aid."','".$status."');")){
mysqli_close($con1);
?><script type="text/javascript">
location.href="single_question_private.php";
</script>
<?php
}else{
mysqli_close($con1);
?><script type="text/javascript">
window.history.back();
alert("Unable to like/dislike this Answer");
</script>
<?php
}

}
}
?>