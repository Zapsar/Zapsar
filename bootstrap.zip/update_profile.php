<?php
include("creds.php");
include("upload_file.php");
session_start();
$uname=$_SESSION["auth_uname"];
$fname=$_POST["fname"];
$lname=$_POST["lname"];
$website=$_POST["website"];
$country=$_POST["country"];
$about_me=$_POST["about_me"];
$facebook_link=$_POST["facebook_link"];
$twitter_link=$_POST["twitter_link"];
$linkedin_link=$_POST["linkedin_link"];
$googleplus_link=$_POST["googleplus_link"];

$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
?>
<script type="text/javascript">
window.history.back();
alert("We're having trouble with our servers");
</script>
<?php
}
else{
$uploadOK=false;
$picture=$_FILES["picture_file"]["name"];
$ext = $_FILES["picture_file"]["size"];
    	
if($ext!=false){
if(mysqli_query($con,"insert into pid values(null);")){
$pres=mysqli_query($con,"select sno from pid order by sno desc limit 1;");
$d=mysqli_fetch_array($pres,MYSQLI_ASSOC);
$pid=$d["sno"];
$picture=upload_file($pid);
}
}else{
$picture="";
}

$uname=mysqli_real_escape_string($con,$uname);
$fname=mysqli_real_escape_string($con,$fname);
$lname=mysqli_real_escape_string($con,$lname);
$about_me=mysqli_real_escape_string($con,$about_me);
$website=mysqli_real_escape_string($con,$website);
$country=mysqli_real_escape_string($con,$country);
$facebook_link=mysqli_real_escape_string($con,$facebook_link);
$twitter_link=mysqli_real_escape_string($con,$twitter_link);
$linkedin_link=mysqli_real_escape_string($con,$linkedin_link);
$googleplus_link=mysqli_real_escape_string($con,$googleplus_link);



$res2=mysqli_query($con,"select username from user_profile where username=AES_ENCRYPT('".$uname."','".$mysql_key."');");
if(mysqli_num_rows($res2)>0){

if($picture!=""){
mysqli_query($con,"update user_profile set photo='".$picture."' where username=AES_ENCRYPT('".$uname."','".$mysql_key."');");
}
if(mysqli_query($con,"update user_profile set fname='".$fname."',lname='".$lname."',country='".$country."',website='".$website."',about='".$about_me."',googleplus='".$googleplus_link."',facebook='".$facebook_link."',twitter='".$twitter_link."',linkedin='".$linkedin_link."',last_updated=CONCAT(CURRENT_DATE,' ',CURRENT_TIME) where username=AES_ENCRYPT('".$uname."','".$mysql_key."');")){
mysqli_close($con);
?>
<script type="text/javascript">
location.href="user_profile.php";
alert("Profile Updated successfully");
</script>
<?php
}else{
mysqli_close($con);
?>
<script type="text/javascript">
window.history.back();
alert("Unable to update your profile. Please try again...");
</script>
<?php
}
}else{
if(mysqli_query($con,"insert into user_profile values(null,AES_ENCRYPT('".$uname."','".$mysql_key."'),'".$fname."','".$lname."','".$picture."','".$country."','".$website."','".$about_me."','".$googleplus_link."','".$facebook_link."','".$twitter_link."','".$linkedin_link."',CONCAT(CURRENT_DATE,' ',CURRENT_TIME));")){
mysqli_close($con);
?>
<script type="text/javascript">
location.href="user_profile.php";
alert("Voila!, Profile Updated successfully");
</script>
<?php
}else{
mysqli_close($con);
?>
<script type="text/javascript">
window.history.back();
alert("Unable to update your profile. Please try again...");
</script>
<?php
}
}
}


?>