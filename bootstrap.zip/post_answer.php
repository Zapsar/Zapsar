<?php
include("creds.php");
include("stats.php");

session_start();

$uname=$_SESSION["auth_uname"];
$answer=$_POST["comment"];
$qid=$_SESSION["single_ques_pri_id"];

if($answer==""){
?>
<script type="text/javascript">
window.history.back();
alert("You haven't specified any answer");
</script>
<?php
}
else{
$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
?>
<script type="text/javascript">
//location.href="single_question_private.php";
window.history.back();
alert("We're having some problem with our servers.");
</script>
<?php
}
else{
$answer=mysqli_real_escape_string($con,$answer);

if(mysqli_query($con,"insert into aids values(null);")){
$aid="";
$res=mysqli_query($con,"select aid from aids order by aid DESC limit 1;");
$data=mysqli_fetch_array($res,MYSQLI_ASSOC);
$aid=$data["aid"];

if(mysqli_query($con,"insert into answer_table values(null,AES_ENCRYPT('".$uname."','".$mysql_key."'),CONCAT('A','".$aid."'),'".$qid."','".$answer."',CONCAT(CURRENT_DATE,' ',CURRENT_TIME));")){
if(mysqli_query($con,"update questions_table set status='s' where qid='".$qid."';")){
$res=mysqli_query($con,"select AES_DECRYPT(username,'".$mysql_key."') as 'username',qid,title,details,tag,custom_tags,views,post_date from questions_table where qid='".$qid."';");
$data=mysqli_fetch_array($res,MYSQLI_ASSOC);
$_SESSION["single_ques_pri_id"]=$data["qid"];
$_SESSION["single_ques_pri_title"]=$data["title"];
$_SESSION["single_ques_pri_details"]=$data["details"];
$_SESSION["single_ques_pri_custom_tags"]=$data["custom_tags"];
$_SESSION["single_ques_pri_tag"]=$data["tag"];
$_SESSION["single_ques_pri_author"]=$data["username"];
$_SESSION["single_ques_pri_post_date"]=$data["post_date"];
$_SESSION["single_ques_pri_status"]='s';
$_SESSION["single_ques_pri_views"]=$data["views"];
$_SESSION["single_ques_pri_likes"]=getLikesCount($data["qid"]);
$_SESSION["single_ques_pri_fav"]=getFavQuestionStatus($data["qid"]);

$rs=mysqli_query($con,"select count('".$qid."') as 'count' from answer_table where qid='".$qid."';");
$data=mysqli_fetch_array($rs,MYSQLI_ASSOC);
$_SESSION["single_ques_pri_answers"]=$data["count"];

$pres=mysqli_query($con,"select photo from user_profile where username=AES_ENCRYPT('".$data["username"]."','".$mysql_key."');");
if(mysqli_num_rows($pres)>0){
$pdata=mysqli_fetch_array($pres,MYSQLI_ASSOC);
$picture=$pdata["photo"];
}else{
$picture="avatar.png";
}
if($picture==""){
$picture="avatar.png";
}
$_SESSION["single_ques_pri_picture"]=$picture;

mysqli_close($con);

?>
<script type="text/javascript">
location.href="single_question_private.php";
alert("AWESOME!, Your answer posted successfully.");
</script>
<?php
}else{
?>
<script type="text/javascript">
//location.href="single_question_private.php";
window.history.back();
alert("SORRY, not able to publish your question. Please Try again...");
</script>
<?php
}
}else{
?>
<script type="text/javascript">
//location.href="single_question_private.php";
window.history.back();
alert("SORRY, not able to publish your question. Please Try again...");
</script>
<?php
}
}
else{
?>
<script type="text/javascript">
//location.href="single_question_private.php";
window.history.back();
alert("SORRY, not able to publish your question. Please Try again...");
</script>
<?php
}
}
}




?>