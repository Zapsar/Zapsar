<?php
//$name=$_POST["name"];
//$email=$_POST["email"];
//$subject=$_POST["subject"];
//$message=$_POST["message"];
$name="Abhijeet";
$email="abhijeet.techbuzz@gmail.com";
$subject="Mail Test";
$message="Working on PHP mail function";
if($name==""||$email==""||$subject==""||$message==""){
?><script type="text/javascript">
window.history.back();
alert("Required fields cannot be left empty");
</script>
<?php
}else{
$message="Hi Zapsar team, This is ".$name.". "+$message;
$message=wordwrap($message,70);
$to="abhijeet.jeet07@gmail.com";
if(mail($to,$subject,$message)){
echo "Mail Sent";
}else{
?><script type="text/javascript">
location.href="contact_us.php";
alert("Thank You for your time, your response has been sent successfully.");
</script>
<?php
}
}
?>