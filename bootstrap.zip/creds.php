<?php
//clearDB creds
//$mysql_host="us-cdbr-iron-east-03.cleardb.net";
//$mysql_user="bc078b58937b31";
//$mysql_password="0f52f2db";
//$mysql_port="3306";
//$mysql_db="ad_dd185cef436b56d";
//$mysql_key="zapsar@123";

$mysql_host="us-cdbr-iron-east-03.cleardb.net";
$mysql_user="bc078b58937b31";
$mysql_password="0f52f2db";
$mysql_port=3306;
$mysql_db="ad_dd185cef436b56d";

//$mysql_host="zaps3800113162.db.3800113.hostedresource.com";
//$mysql_user="zaps3800113162";
//$mysql_password="L8{dRfx,7A";
//$mysql_port=3310;
//$mysql_db="zaps3800113162";
$mysql_key="zapsar@123";
?>