<?php
//code 0 error
//code 1 upload ok
//code 2 file not image
//code 3 file too large
//code 4 file extension wrong
function upload_file($pid){
$target_dir = "images/";
$target_file = $target_dir . basename($_FILES["picture_file"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

// Check file size
if ($_FILES["picture_file"]["size"] > 51200) {
    return 3;
}

// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
   return 4;
}

if (move_uploaded_file($_FILES["picture_file"]["tmp_name"],$target_dir."photo".$pid.".".$imageFileType)) {
        return "photo".$pid.".".$imageFileType;
    } else {
        return 0;
    }
}


?>