<?php
include("creds.php");
include("stats.php");
session_start();
$uname=$_SESSION["auth_uname"];
$qid=$_SESSION["single_ques_pri_id"];

$status=$_POST["like_field"];

$con1=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con1->connect_error){
?>
<script type="text/javascript">
window.history.back();
alert("Not able to like/dislike this question, Server not responding");
</script>
<?php
}
else{
$res=mysqli_query($con1,"select * from questions_like where username=AES_ENCRYPT('".$uname."','".$mysql_key."') and qid='".$qid."';");
if(mysqli_num_rows($res)>0){
if(mysqli_query($con1,"update questions_like set status='".$status."' where username=AES_ENCRYPT('".$uname."','".$mysql_key."') and qid='".$qid."';")){
$_SESSION["single_ques_pri_likes"]=getLikesCount($qid);
mysqli_close($con1);
?><script type="text/javascript">
location.href="single_question_private.php";
</script>
<?php
}else{
mysqli_close($con1);
?><script type="text/javascript">
window.history.back();
alert("Unable to like/dislike this Question");
</script>
<?php
}
}else{
if(mysqli_query($con1,"insert into questions_like values(AES_ENCRYPT('".$uname."','".$mysql_key."'),'".$qid."','".$status."');")){
$_SESSION["single_ques_pri_likes"]=getLikesCount($qid);
mysqli_close($con1);
?><script type="text/javascript">
location.href="single_question_private.php";
</script>
<?php
}else{
mysqli_close($con1);
?><script type="text/javascript">
window.history.back();
alert("Unable to like/dislike this Question");
</script>
<?php
}

}
}
?>