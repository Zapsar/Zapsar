<?php
error_reporting(E_ALL & ~E_NOTICE);
session_start();
$uname=$_SESSION["auth_uname"];
if($uname==""){
?>
<script type="text/javascript">
location.href="index.php";
</script>
<?php 
}

?>
