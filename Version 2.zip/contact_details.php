<?php
$c_about="We might not have answers of all our queries but the world has & we are here to connect you with them.";
$c_email="support@zapsar.com";
$c_address="ZAPSAR Technologies,<br/>
Kumaun Resort, Court Road,<br/>
Jaspur Khurd, Kashipur, U.K. (244713)";
$c_phone="(+91) 7535810410";
$c_facebook="https://www.facebook.com/Zapsartechnologies";
$c_youtube="https://www.youtube.com/channel/UCPDYVnxvevvO67r-NT-k6FQ";
$c_twitter="https://twitter.com/followzapsar";
$c_linkedin="https://www.linkedin.com/company/zapsartechnologies";

?>