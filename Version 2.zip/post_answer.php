<?php
include("creds.php");
include("stats.php");

session_start();

$uname=$_SESSION["auth_uname"];
$answer=$_POST["comment"];
$qid=$_SESSION["single_ques_pri_id"];

if($answer=="" || !preg_match('/[A-Za-z]/',$answer)){
echo '<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap/css/bootstrap.css">
<script src="js/jquery.js" ></script>
<script src="bootstrap/js/bootstrap.js" ></script>
</head>
<body onclick="window.history.back();">
<div id="show_alert" class="modal fade" role="dialog">
  <div class="modal-dialog" role="document">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">ANSWER NOT SPECIFIED</h4>
      </div>
      <div class="modal-body">
	 <div class="alert alert-danger alert-dismissible fade in" role="alert" style="margin-top:0px">
<span class="glyphicon glyphicon-remove-sign" aria-hidden="true"></span><strong> Important! </strong>You have not specified any answer, please provide a brief explanation if your answer is too short. 
</div>
<div class="alert alert-info alert-dismissible fade in" role="alert" style="margin-top:0px">
If Confirm Form Resubmission page occurs, try to reload again. <span class="glyphicon glyphicon-refresh" aria-hidden="true"></span>
</div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
$("#show_alert").modal();
</script>
</body></html>';
}
else{
$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
echo '<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap/css/bootstrap.css" >
<script src="js/jquery.js" ></script>
<script src="bootstrap/js/bootstrap.js" ></script>
</head>
<body onclick="window.history.back();">
<div id="show_alert" class="modal fade" role="dialog">
  <div class="modal-dialog" role="document">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">SERVER PROBLEM</h4>
      </div>
      <div class="modal-body">
	 <div class="alert alert-info alert-dismissible fade in" role="alert" style="margin-top:0px">
<span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span><strong> Oh Snap! </strong>We are having problem with our server, Please try again... 
</div>
<div class="alert alert-info alert-dismissible fade in" role="alert" style="margin-top:0px">
If Confirm Form Resubmission page occurs, try to reload again. <span class="glyphicon glyphicon-refresh" aria-hidden="true"></span>
</div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
$("#show_alert").modal();
</script>
</body></html>';
}
else{
$answer=mysqli_real_escape_string($con,$answer);

if(mysqli_query($con,"insert into aids values(null);")){
$aid="";
$res=mysqli_query($con,"select aid from aids order by aid DESC limit 1;");
$data=mysqli_fetch_array($res,MYSQLI_ASSOC);
$aid=$data["aid"];

if(mysqli_query($con,"insert into answer_table values(null,AES_ENCRYPT('".$uname."','".$mysql_key."'),CONCAT('A','".$aid."'),'".$qid."','".$answer."',CONVERT_TZ(UTC_TIMESTAMP(),'+0:00','+5:30'));")){
if(mysqli_query($con,"update questions_table set status='s' where qid='".$qid."';")){
$res=mysqli_query($con,"select AES_DECRYPT(username,'".$mysql_key."') as 'username',qid,title,details,tag,custom_tags,views,post_date from questions_table where qid='".$qid."';");
$data=mysqli_fetch_array($res,MYSQLI_ASSOC);
$_SESSION["single_ques_pri_id"]=$data["qid"];
$_SESSION["single_ques_pri_title"]=htmlentities($data["title"],ENT_QUOTES);
$_SESSION["single_ques_pri_details"]=htmlentities($data["details"],ENT_QUOTES);
$_SESSION["single_ques_pri_custom_tags"]=$data["custom_tags"];
$_SESSION["single_ques_pri_tag"]=$data["tag"];
$_SESSION["single_ques_pri_author"]=$data["username"];
$_SESSION["single_ques_pri_post_date"]=$data["post_date"];
$_SESSION["single_ques_pri_status"]='s';
$_SESSION["single_ques_pri_views"]=$data["views"];
$_SESSION["single_ques_pri_likes"]=getLikesCount($data["qid"]);
$_SESSION["single_ques_pri_fav"]=getFavQuestionStatus($data["qid"]);

$pres=mysqli_query($con,"select photo from user_profile where username=AES_ENCRYPT('".$data["username"]."','".$mysql_key."');");
if(mysqli_num_rows($pres)>0){
$pdata=mysqli_fetch_array($pres,MYSQLI_ASSOC);
$picture=$pdata["photo"];
}else{
$picture="avatar.png";
}
if($picture==""){
$picture="avatar.png";
}
$_SESSION["single_ques_pri_picture"]=$picture;

$rs=mysqli_query($con,"select count('".$qid."') as 'count' from answer_table where qid='".$qid."';");
$data=mysqli_fetch_array($rs,MYSQLI_ASSOC);
$_SESSION["single_ques_pri_answers"]=$data["count"];

mysqli_close($con);

echo '<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap/css/bootstrap.css" >
<script src="js/jquery.js" ></script>
<script src="bootstrap/js/bootstrap.js" ></script>
</head>
<body onclick="load_page()">
<div id="show_alert" class="modal fade" role="dialog">
  <div class="modal-dialog" role="document">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">ANSWER PUBLISHED</h4>
      </div>
      <div class="modal-body">
	 <div class="alert alert-success alert-dismissible fade in" role="alert" style="margin-top:0px">
<span class="glyphicon glyphicon-success-sign" aria-hidden="true"></span><strong> AWESOME! </strong>Your answer published successfully. 
</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
$("#show_alert").modal();
function load_page(){
location.href="single_question_private.php";
}
</script>
</body></html>';
}else{
redirect($con);
}
}else{
redirect($con);
}
}
else{
redirect($con);
}
}
}
function redirect($con){
mysqli_close($con);
echo '<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap/css/bootstrap.css" >
<script src="js/jquery.js" ></script>
<script src="bootstrap/js/bootstrap.js" ></script>
</head>
<body onclick="window.history.back();">
<div id="show_alert" class="modal fade" role="dialog">
  <div class="modal-dialog" role="document">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">SERVER PROBLEM</h4>
      </div>
      <div class="modal-body">
	 <div class="alert alert-info alert-dismissible fade in" role="alert" style="margin-top:0px">
<span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span><strong> Oh Snap! </strong>We are having problem with our server, Please try again... 
</div>
<div class="alert alert-info alert-dismissible fade in" role="alert" style="margin-top:0px">
If Confirm Form Resubmission page occurs, try to reload again. <span class="glyphicon glyphicon-refresh" aria-hidden="true"></span>
</div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
$("#show_alert").modal();
</script>
</body></html>';
}




?>