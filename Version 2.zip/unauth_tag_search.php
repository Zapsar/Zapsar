<?php
include("creds.php");
$tag_filter=$_POST["tag_filter"];
$tag_filter=strtolower($tag_filter);
$prev_tag_filter=$_POST["prev_tag_filter"];

$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
$rs=mysqli_query($con,"select * from questions_table where tag='".$tag_filter."' or custom_tags like '%".$tag_filter."%' order by CONVERT(SUBSTR(qid,2),SIGNED INTEGER) desc;");
if(mysqli_num_rows($rs)>0){
echo '<form id="form1" action="cat_question.php" method="post">
<input type="hidden" name="tag_filter" value="'.$tag_filter.'">
</form>';
?>
<script type="text/javascript">
document.getElementById("form1").submit();
</script>
<?php
}else{
echo '<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap/css/bootstrap.css" >
<script src="js/jquery.js" ></script>
<script src="bootstrap/js/bootstrap.js" ></script>
</head>
<body onclick="load_page()">
<form id="form1" action="cat_question.php" method="post">
<input type="hidden" name="tag_filter" value="'.$prev_tag_filter.'">
</form>
<div id="show_alert" class="modal fade" role="dialog">
  <div class="modal-dialog" role="document">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">NOT QUESTION FOUND</h4>
      </div>
      <div class="modal-body">
	 <div class="alert alert-info alert-dismissible fade in" role="alert" style="margin-top:0px">
<span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span><strong> Sorry! </strong>There are no questions with this tag, try another one or login to ask question with this tag. 
</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
$("#show_alert").modal();
function load_page(){
document.getElementById("form1").submit();
}
</script>
</body></html>';
}
?>
