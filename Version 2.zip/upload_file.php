<?php
//code 1 error
//code 2 file too large
//code 3 file extension wrong
function upload_file($pid){
$target_dir = "images/";
$target_file = $target_dir . basename($_FILES["picture_file"]["name"]);
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

// Check file size
if ($_FILES["picture_file"]["size"] > 71680) {
    return 2;
}

// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
   return 3;
}

if (move_uploaded_file($_FILES["picture_file"]["tmp_name"],$target_dir."photo".$pid.".".$imageFileType)) {
        return "photo".$pid.".".$imageFileType;
    } else {
        return 1;
    }
}


?>