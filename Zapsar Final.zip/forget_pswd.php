<?php
$uname=$_POST["user_name"];
$email=$_POST["user_email"];

include("creds.php");
include("contact_details.php");

if($uname==""||$email==""){
?>
<script type="text/javascript">
window.history.back();
alert("Required fields cannot be empty.");
</script>
<?php
}
else{
$con1=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con1->connect_error){
?>
<script type="text/javascript">
window.history.back();
alert("We're having problem with our server, Please try again...");
</script>
<?php
}
else{
$uname=strtolower($uname);
$email=strtolower($email);

$uname=mysqli_real_escape_string($con1,$uname);
$email=mysqli_real_escape_string($con1,$email);

$rs=mysqli_query($con1,"select email,AES_DECRYPT(pswd,'".$mysql_key."') as 'pswd' from user_creds where username=AES_ENCRYPT('".$uname."','".$mysql_key."');");
if(mysqli_num_rows($rs)>0){
$data=mysqli_fetch_array($rs,MYSQLI_ASSOC);
$reg_email=$data["email"];
$pswd=$data["pswd"];
if($email==$reg_email){
mysqli_close($con1);

$subject="Reset Password";
$message="Please immediately change the password after logging in.\nYour password for login is: ".$pswd."\n\nIf still having problem in logging, please let us know.\nThanks, Zapsar Team";
$message="Hi, ".$uname."\n".$message;
//$message=wordwrap($message,120);
$to=$email;
$header="MIME-Version: 1.0"."\r\n";
$header.="Content-type:text/plain;charset=UTF-8"."\r\n";
$header.="From: Zapsar Team <".$c_email.">";
if(mail($to,$subject,$message,$header)){
?>
<script type="text/javascript">
location.href="index.php";
alert("Please check your registered email, we have sent a mail.");
</script>
<?php
}else{
?>
<script type="text/javascript">
window.history.back();
alert("Not able to recover password, Please Try Again....");
</script>
<?php
}
}else{
mysqli_close($con1);
?>
<script type="text/javascript">
window.history.back();
alert("This email is not registered with this username, use only registered email.");
</script>
<?php
}
}else{
mysqli_close($con1);
?>
<script type="text/javascript">
window.history.back();
alert("This username is not registered with us.");
</script>
<?php
}

}
}


?>