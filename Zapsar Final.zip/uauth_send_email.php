<?php
include("contact_details.php");

$name=$_POST["name"];
$email=$_POST["email"];
$subject=$_POST["subject"];
$message=$_POST["message"];
if($name==""||$email==""||$subject==""||$message==""){
?>
<script type="text/javascript">
window.history.back();
alert("Required fields cannot be left empty");
</script>
<?php
}else{
$email=strtolower($email);
$name=strtolower($name);
$name=ucwords($name);
$subject=strtolower($subject);
$subject=ucwords($subject);

$message="Hi Zapsar team,\nThis is ".$name." and my email is < ".$email." >.\n\n".$message;
$message=wordwrap($message,120);
$to=$c_email;
$header="MIME-Version: 1.0"."\r\n";
$header.="Content-type:text/plain;charset=UTF-8"."\r\n";
$header.="From: Zapsar User <".$email.">";
if(mail($to,$subject,$message,$header)){
?>
<script type="text/javascript">
location.href="contact_us.php";
alert("Thank You for your time, your response has been sent successfully.");
</script>
<?php
}else{
?>
<script type="text/javascript">
window.history.back();
alert("Not able to send your query, Please Try Again....");
</script>
<?php
}
}
?>