﻿<?php
session_start();
if(!isset($_SESSION["auth_uname"])){
?>
<script>location.href="index.php"</script>
<?php
}else{
$uname=$_SESSION["auth_uname"];
}
include("stats.php");
include("creds.php");
include("contact_details.php");
error_reporting(E_ALL & ~E_NOTICE);

$fetchRows=10;
if($_POST["load_more"]=="yes"){
$curr_pag=$_POST["curr_pag"];
$start_limit=($curr_pag-1)*$fetchRows;
}else{
$curr_pag=1;
$start_limit=0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
 
<meta charset="utf-8">
<title>Zapsar – We Have Answers</title>
<meta name="description" content="Zapsar We Have Answers">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
<meta name="author" content="abhi@tech">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="css/skins.css">
<link rel="stylesheet" href="css/responsive.css">
 
<link rel="shortcut icon" href="images/favicon.png">
<script src="js/jquery.js"></script>
<script src="js/jquery.min.js"></script>

<!--Pre Color:#ff7361-->
<style>
a {
    text-decoration: none;
}

a:hover {
    text-decoration: none;
}

a:focus {
    text-decoration: none;
}
#singleQuesTitle{
background:transparent;
color:black;
padding:0px;
font-size:20px;
}

#singleQuesTitle:hover{
color:#34dddd;
}

#singleQuesTitle:focus{
color:#34dddd;
}

</style>
</head>

<body>
<div class="loader"><div class="loader_html"></div></div>
<div id="wrap" class="grid_1200">
<!--------------------------------------------- Header   ------------------------------------------>
<header id="header" style="background:#34dddd">
<section class="container clearfix" >
<div class="logo"><a href="index_private.php"><img alt="" src="images/logo.png"></a></div>
<nav class="navigation"  >
<ul class="">
<li class="current_page_item"><a href="index_private.php">Home</a></li>
<li style="cursor:pointer"><a>Tags</a>
<ul id="tag_list">
<li><a >Admission</a></li>
<li><a >Android</a></li>
<li><a >Animation</a></li>
<li><a >Arts</a></li>
<li><a >Books</a></li>
<li><a >Business</a></li>
<li><a >Cloud</a></li>
<li><a >Computer</a></li>
<li><a >Database</a></li>
<li><a >Fitness</a></li>
<li><a >Finance</a></li>
<li><a >Food</a></li>
<li><a >Hardware</a></li>
<li><a >History</a></li>
<li><a >Literature</a></li>
<li><a >Maths</a></li>
<li><a >Medical</a></li>
<li><a >Operating System</a></li>
<li><a >Programming</a></li>
<li><a >Research</a></li>
<li><a >Science</a></li>
<li><a >Smartphones</a></li>
<li><a >Software</a></li>
<li><a >Sports</a></li>
<li><a >Technology</a></li>
<li><a>Web Development</a></li>
</ul>
<script type="text/javascript">
document.getElementById("tag_list").onclick=function(evt){
document.getElementById("tag_filter_input").value=evt.target.innerHTML;
document.getElementById("nav_tag_search").submit();
}
</script>
<form id="nav_tag_search" action="cat_question_private.php" method="post" style="width:0px;height:0px">
<input type="hidden" name="tag_filter" id="tag_filter_input">
</form>
</li>

<li><a href="ask_question.php">Ask Question</a></li>

<li><a style="cursor:pointer">User Profile</a><ul>
<li><a href="user_questions.php">Questions</a></li>
<li><a href="user_answers.php">Answers</a></li>
<li><a href="user_favorite_questions.php">Favorite Questions</a></li>
<li><a href="user_points.php">Points</a></li>
<li><a href="user_profile.php">View Profile</a></li>
<li><a href="edit_profile.php">Edit Profile</a></li>
</ul>
</li>

<li><a href="contact_us_private.php">Contact Us</a></li>
<li><a style="cursor:pointer" href="finish_session.php" role="button" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="<?php echo "Hi! ".$_SESSION["auth_uname"];?>">Logout</a></li>
</ul>
</nav>
</section> 
</header> 

 
<div class="breadcrumbs">
<section class="container">
<div class="row">
<div class="col-md-12">
<h1>User Answers : <?php echo $_SESSION["auth_uname"];?></h1>
</div>
<div class="col-md-12">
<div class="crumbs">
<a href="index_private.php">Home</a>
<span class="crumbs-span">/</span>
<a>User</a>
<span class="crumbs-span">/</span>
<span class="current">User Answers : <?php echo $_SESSION["auth_uname"];?></span>
</div>
</div>
</div> 
</section> 
</div> 
<section class="container main-content">
<div class="row">
<div class="col-md-9">
<div class="row">
<div class="user-profile">
<div class="col-md-12">
<div class="page-content page-content-user-profile">
<div class="user-profile-widget">
<h2>User Stats</h2>
<div class="ul_list ul_list-icon-ok">
<ul>
<li><i class="icon-question-sign"></i><a href="user_questions.php">Questions<span> ( <span><?php echo getUserQuestionStats();?></span> ) </span></a></li>
<li><i class="icon-comment"></i><a href="user_answers.php">Answers<span> ( <span><?php echo getUserAnswerStats();?></span> ) </span></a></li>
<li><i class="icon-star"></i><a href="user_favorite_questions.php">Favorite Questions<span> ( <span><?php echo getUserFavQuestionStats();?></span> ) </span></a></li>
<li><i class="icon-heart"></i><a href="user_points.php">Points<span> ( <span><?php echo $_SESSION["user_points"];?></span> ) </span></a></li>
</ul>
</div>
</div> 
</div> 
</div> 
</div> 
</div> 
<div class="clearfix"></div>

<?php

$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
?>
<script type="text/javascript">
alert("We're having some problem with our servers.");
</script>
<?php
}
else{
$rs=mysqli_query($con,"select qid from answer_table where username=AES_ENCRYPT('".$_SESSION["auth_uname"]."','".$mysql_key."') order by CONVERT(SUBSTR(aid,2),SIGNED INTEGER) DESC;");
if(mysqli_num_rows($rs)>0){
$qid_arr=array();
$i=0;
while($data=mysqli_fetch_array($rs,MYSQLI_ASSOC)){
$qid_arr[$i]=$data["qid"];
$i++;
}
$unique_qid=array_unique($qid_arr);
$len=count($unique_qid);
$rowsCount=$len;

$new_arr=array();
$i=0;
foreach($unique_qid as $v){
$new_arr[$i]=$v;
$i++;
}
for($l=$start_limit,$userAnswers=0;$l<($start_limit+$fetchRows)&&$l<$len;$l++,$userAnswers++){
$val=$new_arr[$l];

//foreach($unique_qid as $val){
$resource=mysqli_query($con,"select AES_DECRYPT(username,'".$mysql_key."') as 'username',qid,title,details,tag,custom_tags,status,views,post_date from questions_table where qid='".$val."';");

$result=mysqli_fetch_array($resource,MYSQLI_ASSOC);
$title=$result["title"];
$qid=$result["qid"];
$details=$result["details"];
$author=$result["username"];
$status=$result["status"];
$custom_tags=$result["custom_tags"];
$tag=$result["tag"];
$post_date=$result["post_date"];
$fav=getFavQuestionStatus($qid);

$res=mysqli_query($con,"select count('".$qid."') as 'count' from answer_table where qid='".$qid."';");
$result1=mysqli_fetch_array($res,MYSQLI_ASSOC);
$answers=$result1["count"];

$res=mysqli_query($con,"select count('".$qid."') as 'count' from answer_table where qid='".$qid."' and username=AES_ENCRYPT('".$_SESSION["auth_uname"]."','".$mysql_key."');");
$result1=mysqli_fetch_array($res,MYSQLI_ASSOC);
$user_answers=$result1["count"];

$pres=mysqli_query($con,"select photo from user_profile where username=AES_ENCRYPT('".$author."','".$mysql_key."');");
if(mysqli_num_rows($pres)>0){
$pdata=mysqli_fetch_array($pres,MYSQLI_ASSOC);
$picture=$pdata["photo"];
}else{
$picture="avatar.png";
}
if($picture==""){
$picture="avatar.png";
}

echo '<form action="single_question_private.php" method="POST">
<article class="question question-type-normal">
<h2>
<input id="singleQuesTitle" type="submit" value="';
if(strlen($title)>50)echo substr($title,0,50)."...";else echo $title;
echo '" >
</h2>
<div class="question-type-main"><i class="icon-question-sign"></i>Question</div>
<div class="question-author">
<a  original-title="'.$author.'" class="question-author-img tooltip-n"><span></span><img alt="" src="images/'.$picture.'"></a>
</div>
<div class="question-inner">
<div class="clearfix"></div>
<p class="question-desc" style="border:none;padding-bottom:0px">';
if(strlen($details)>230)echo substr($details,0,230)."...";else echo $details;
echo '</p>
</div> 
<div id="commentlist" class="question-inner page-content"  style="box-shadow:none;border:none">
<div class="boxedtitle page-title" ><h2>Answers ( <span class="color">'.$user_answers.'</span> )</h2></div>';

if($user_answers>0){
$rs=mysqli_query($con,"select AES_DECRYPT(username,'".$mysql_key."') as 'username',aid,qid,answer,post_date from answer_table where qid='".$qid."' and username=AES_ENCRYPT('".$_SESSION["auth_uname"]."','".$mysql_key."') order by CONVERT(SUBSTR(aid,2),SIGNED INTEGER) desc;");
while($data=mysqli_fetch_array($rs,MYSQLI_ASSOC)){
$ansLikesCount=getAnsLikesCount($data["aid"]);

echo '<ol class="commentlist clearfix">
<li class="comment" style="margin-top:10px">
<div class="comment-body comment-body-answered clearfix">
<div class="avatar"><img alt="" src="images/'.$_SESSION["user_photo"].'"></div>
<div class="comment-text">
<div class="author clearfix">
<div class="comment-author"><a>'.$_SESSION["auth_uname"].'</a></div>';
if(getAnswerLikeStatus($data["aid"])=="l"){
echo '<div class="comment-vote">
<ul class="question-vote">
<li><a class="question-vote-up" title="You Liked It"></a></li>
<li><a class="question-vote-down" title="Dislike"></a></li>
</ul>
</div>
<span class="question-vote-result" style="color:#338338">'.$ansLikesCount.'</span>';
}else if(getAnswerLikeStatus($data["aid"])=="d"){
echo '<div class="comment-vote">
<ul class="question-vote">
<li><a class="question-vote-up" title="Like"></a></li>
<li><a class="question-vote-down" title="You Disliked It"></a></li>
</ul>
</div>
<span class="question-vote-result" style="color:#990707">'.$ansLikesCount.'</span>';
}else if(getAnswerLikeStatus($data["aid"])=="none"){
echo '<div class="comment-vote">
<ul class="question-vote">
<li><a class="question-vote-up" title="Like"></a></li>
<li><a class="question-vote-down" title="Dislike"></a></li>
</ul>
</div>
<span class="question-vote-result">'.$ansLikesCount.'</span>';
}
echo '<div class="comment-meta">
<div class="date"><i class="icon-time"></i>'.getAnsPostDateTime($data["post_date"]).'</div>
</div>
<!--<a class="comment-reply" ><i class="icon-reply"></i>Reply</a>-->
</div>
<div class="text"><p><pre >'.nl2br(htmlentities($data["answer"],ENT_QUOTES)).'</pre></p>
</div>';
if($ansLikesCount>0){
if(getBestAnsStatus($data["aid"])=="best"){
echo '<div class="question-answered question-answered-done"><i class="icon-ok"></i>Best Answer</div>';
}
}
echo '</div></div></li></ol>';


}
 }

echo '</div>
</article>
<!--<a  class="load-questions"><i class="icon-refresh"></i>Load More Questions</a>-->
<!-- Hidden Fields-->
<input type="hidden" name="single_ques_pri_title" value="'.$title.'">
<input type="hidden" name="single_ques_pri_id" value="'.$qid.'">
<input type="hidden" name="single_ques_pri_details" value="'.$details.'">
<input type="hidden" name="single_ques_pri_author" value="'.$author.'">
<input type="hidden" name="single_ques_pri_status" value="'.$status.'">
<input type="hidden" name="single_ques_pri_answers" value="'.$answers.'">
<input type="hidden" name="single_ques_pri_fav" value="'.$fav.'">
<input type="hidden" name="single_ques_pri_custom_tags" value="'.$custom_tags.'">
<input type="hidden" name="single_ques_pri_tag" value="'.$tag.'">
<input type="hidden" name="single_ques_pri_picture" value="'.$picture.'">
<input type="hidden" name="single_ques_pri_post_date" value="'.$post_date.'">
<input type="hidden" name="through_post_method" value="true">
</form>';
}
}else{
$rowsCount=0;
$userAnswers=0;
?>
<script type="text/javascript">
alert("You haven't answered any questions yet.");
</script>
<?php
}
}
mysqli_close($con);

if($rowsCount>$userAnswers){
echo '<div id="pag_div" class="pagination">';
for($d=1;$d<=ceil($rowsCount/$fetchRows);$d++){
if($curr_pag==$d){
echo '<span class="current" style="cursor:pointer">'.$d.'</span>';
}else{
echo '<span style="cursor:pointer">'.$d.'</span>';
}
}
echo '</div>'; 
echo '<script>
document.getElementById("pag_div").onclick=function(evt){
document.getElementById("curr_pag").value=evt.target.innerHTML;
document.getElementById("load_more_form").submit();
}
</script>';

}

?>
</div> 
<form id="load_more_form" method="post" action="">
<input type="hidden" id="curr_pag" name="curr_pag" value="<?php echo $curr_pag;?>">
<input type="hidden" name="load_more" value="yes">
</form>

<aside class="col-md-3 sidebar">
<div class="widget widget_stats">
<h3 class="widget_title">Stats</h3>
<div class="ul_list ul_list-icon-ok">
<ul>
<li><i class="icon-question-sign"></i>Questions ( <span><?php echo getQuestionStats();?></span> )</li>
<li><i class="icon-comment"></i>Answers ( <span><?php echo getAnswerStats();?></span> )</li>
</ul>
</div>
</div>
<div class="widget widget_highest_points">
<h3 class="widget_title">Leaderboard</h3>
<ul>
<?php 
$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
?>
<script type="text/javascript">
alert("We're having some problem with our servers.");
</script>
<?php
}
else{
$prs=mysqli_query($con,"select AES_DECRYPT(username,'".$mysql_key."') as 'username',points from user_points where points>0  order by points DESC limit 5;");
if(mysqli_num_rows($prs)>0){
while($pdata=mysqli_fetch_array($prs,MYSQLI_ASSOC)){
$user_name=$pdata["username"];
$user_points=$pdata["points"];

$ares=mysqli_query($con,"select photo from user_profile where username=AES_ENCRYPT('".$user_name."','".$mysql_key."');");
if(mysqli_num_rows($ares)>0){
$adata=mysqli_fetch_array($ares,MYSQLI_ASSOC);
$user_photo=$adata["photo"];
if($user_photo==""){
$user_photo="avatar.png";
}
}else{
$user_photo="avatar.png";
}
echo '<li>
<div class="author-img">
<a ><img width="60" height="60" src="images/'.$user_photo.'" alt=""></a>
</div>
<h6><a >'.$user_name.'</a></h6>
<span class="comment">'.$user_points.' Points</span>
</li>';
}
}else{
echo '<li>
<div class="author-img">
<a ><img width="60" height="60" src="images/avatar.png" alt=""></a>
</div>
<h6><a >Not Available</a></h6>
<span class="comment">0 Points</span>
</li>';
}
mysqli_close($con);
}
?>
</ul>
</div><div class="widget widget_tag_cloud" id="custom_tag_div">
<h3 class="widget_title">Tags</h3>
<?php
$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
?>
<script type="text/javascript">
alert("We're having some problem with our servers.");
</script>
<?php
}
else{
$rs=mysqli_query($con,"select custom_tags from questions_table order by sno desc;");
if(mysqli_num_rows($rs)>0){
$i=0;
while($data=mysqli_fetch_array($rs,MYSQLI_ASSOC)){
if($i==0){
$tags_string=$data["custom_tags"];
$i++;
}else{
$tags_string=$tags_string.",".$data["custom_tags"];
}
}
$tag_array=explode(",",$tags_string);
$unique_tags=array_unique($tag_array);
$i=0;
foreach($unique_tags as $val){
if($i==30){
break;
}
echo '<a style="cursor:pointer">'.$val.'</a>';
$i++;
}
echo '<form id="custom_tag_form" action="cat_question_private.php" method="post" style="width:0px;height:0px">
<input type="hidden" name="tag_filter" id="custom_tag_filter">
</form>';
?>
<script type="text/javascript">
$("#custom_tag_div a").click(function(evt){
document.getElementById("custom_tag_filter").value=evt.target.innerHTML;
document.getElementById("custom_tag_form").submit();
});
</script>
<?php
}
mysqli_close($con);
}
?>

</div>
</aside> 
</div> 
</section> 


<footer id="footer">
<section class="container">
<div class="row">
<div class="col-md-4">
<div class="widget widget_contact">
<h3 class="widget_title" >About Us</h3>
<p><?php echo $c_about;?></p>
<ul>
<li>
<span style="color:#fff">Support :</span>Contact No. : <?php echo $c_phone;?>
</li>
<li>Email : <?php echo $c_email;?></li>
</ul>
</div>
</div>
<div class="col-md-2">
<div class="widget">
<h3 class="widget_title">Quick Links</h3>
<ul>
<li><a href="index_private.php">Home</a></li>
<li><a href="ask_question.php">Ask Question</a></li>
<li><a href="user_profile.php">View Profile</a></li>
<li><a href="edit_profile.php">Edit Profile</a></li>
<li><a href="user_questions.php">User Questions</a></li>
<li><a href="user_answers.php">User Answers</a></li>
<li><a href="user_favorite_questions.php">Favorite Questions</a></li>
<li><a href="user_points.php">User Points</a></li>
<li><a href="contact_us_private.php">Contact Us</a></li>
</ul>

</div>
</div>
<div class="col-md-3">
<div class="widget">
<h3 class="widget_title">Popular Questions</h3>
<ul class="related-posts">
<?php 
$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
?>
<script type="text/javascript">
alert("We're having some problem with our servers.");
</script>
<?php
}
else{
$rs=mysqli_query($con,"select AES_DECRYPT(username,'".$mysql_key."') as 'username',qid,title,details,tag,custom_tags,status,views,post_date from questions_table order by views DESC limit 2;");
if(mysqli_num_rows($rs)>0){
while($data=mysqli_fetch_array($rs,MYSQLI_ASSOC)){
$title=$data["title"];
$qid=$data["qid"];
$details=$data["details"];
$author=$data["username"];
$status=$data["status"];
$custom_tags=$data["custom_tags"];
$tag=$data["tag"];
$post_date=$data["post_date"];
$fav=getFavQuestionStatus($qid);

$res=mysqli_query($con,"select count('".$qid."') as 'count' from answer_table where qid='".$qid."';");
$result=mysqli_fetch_array($res,MYSQLI_ASSOC);
$answers=$result["count"];

$pres=mysqli_query($con,"select photo from user_profile where username=AES_ENCRYPT('".$author."','".$mysql_key."');");
if(mysqli_num_rows($pres)>0){
$pdata=mysqli_fetch_array($pres,MYSQLI_ASSOC);
$picture=$pdata["photo"];
}else{
$picture="avatar.png";
}
if($picture==""){
$picture="avatar.png";
}
?>
<form action="single_question_private.php" method="POST">
<li class="related-item">
<h3><input id="singleQuesTitle" style="font-size:15px;color:white;padding-bottom:5px" type="submit" value="<?php echo substr($title,0,30)."...";?>" ></h3>
<p><?php echo substr($details,0,60)."...";?></p>
<div class="clear"></div><span><?php echo getRegDate($post_date);?></span>
</li>
<input type="hidden" name="single_ques_pri_title" value="<?php echo $title;?>">
<input type="hidden" name="single_ques_pri_id" value="<?php echo $qid;?>">
<input type="hidden" name="single_ques_pri_details" value="<?php echo $details;?>">
<input type="hidden" name="single_ques_pri_author" value="<?php echo $author;?>">
<input type="hidden" name="single_ques_pri_status" value="<?php echo $status;?>">
<input type="hidden" name="single_ques_pri_answers" value="<?php echo $answers;?>">
<input type="hidden" name="single_ques_pri_fav" value="<?php echo $fav;?>">
<input type="hidden" name="single_ques_pri_custom_tags" value="<?php echo $custom_tags;?>">
<input type="hidden" name="single_ques_pri_tag" value="<?php echo $tag;?>">
<input type="hidden" name="single_ques_pri_picture" value="<?php echo $picture;?>">
<input type="hidden" name="single_ques_pri_post_date" value="<?php echo $post_date;?>">
<input type="hidden" name="through_post_method" value="true">
</form>

<?php
}
}
mysqli_close($con);
}
?>
</ul>
</div>
</div>
<div class="col-md-3">
<div class="widget">
<h3 class="widget_title">Frequent Tags</h3>
<div class="related-item" id="freq_tag_div">
<?php 
$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
?>
<script type="text/javascript">
alert("We're having some problem with our servers.");
</script>
<?php
}
else{
$rs=mysqli_query($con,"select count(tag),tag from questions_table group by tag order by count(tag) DESC limit 30;");
if(mysqli_num_rows($rs)>0){
$ci=0;
while($data=mysqli_fetch_array($rs,MYSQLI_ASSOC)){
if($ci==0){
echo '<a style="cursor:pointer">'.ucwords($data['tag']).'</a>';
$ci++;
}else{
echo ', <a style="cursor:pointer">'.ucwords($data['tag']).'</a>';
}
}
echo '<form id="freq_tag_form" action="cat_question_private.php" method="post" style="width:0px;height:0px">
<input type="hidden" name="tag_filter" id="freq_tag_filter">
</form>';
}
mysqli_close($con);
}
?>
<script type="text/javascript">
$("#freq_tag_div a").click(function(evt){
document.getElementById("freq_tag_filter").value=evt.target.innerHTML;
document.getElementById("freq_tag_form").submit();
});
</script>

</div>
</div>
</div>
</div>  
</section> 
</footer> 
<footer id="footer-bottom">
<section class="container">
<div class="copyrights f_left">Copyright &#169 2017 Zapsar</div>
<div class="social_icons f_right">
<ul>
<li class="twitter"><a href="<?php echo $c_twitter;?>" target="_blank" original-title="Twitter" class="tooltip-n" ><i class="social_icon-twitter font17"></i></a></li>
<li class="facebook"><a href="<?php echo $c_facebook;?>" target="_blank" original-title="Facebook" class="tooltip-n" ><i class="social_icon-facebook font17"></i></a></li>
<li class="youtube"><a href="<?php echo $c_youtube;?>" target="_blank" original-title="Youtube" class="tooltip-n" ><i class="social_icon-youtube font17"></i></a></li>
<li class="linkedlin"><a href="<?php echo $c_linkedin;?>" target="_blank" original-title="Linkedin" class="tooltip-n" ><i class="social_icon-linkedin font17"></i></a></li>
</ul>
</div> 
</section> 
</footer> 
</div> 
<div class="go-up"><i class="icon-chevron-up"></i></div>
 
<script src="bootstrap/js/bootstrap.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery-ui-1.10.3.custom.min.js"></script>
<script src="js/jquery.easing.1.3.min.js"></script>
<script src="js/html5.js"></script>
<script src="js/twitter/jquery.tweet.js"></script>
<script src="js/jflickrfeed.min.js"></script>
<script src="js/jquery.inview.min.js"></script>
<script src="js/jquery.tipsy.js"></script>
<script src="js/tabs.js"></script>
<script src="js/jquery.flexslider.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>
<script src="js/jquery.carouFredSel-6.2.1-packed.js"></script>
<script src="js/jquery.scrollTo.js"></script>
<script src="js/jquery.nav.js"></script>
<script src="js/tags.js"></script>
<script src="js/jquery.bxslider.min.js"></script>
<script src="js/custom.js"></script>
 <script>
$(function(){$('[data-toggle="popover"]').popover()})
</script>

 
</body>
</html>