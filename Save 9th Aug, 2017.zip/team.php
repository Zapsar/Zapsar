<?php
include("contact_details.php");
error_reporting(E_ALL & ~E_NOTICE);

?>
<!DOCTYPE html>
<html lang="en">
<head>
 
<meta charset="utf-8">
<title>Zapsar – We Have Answers</title>
<meta name="description" content="Zapsar We Have Answers">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
<meta name="author" content="abhi@tech">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="css/skins.css">
<link rel="stylesheet" href="css/responsive.css">
 
<link rel="shortcut icon" href="images/favicon.png">
<script src="js/jquery.js"></script>
<script src="js/jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.js"></script> 

<!--Pre Color:#ff7361-->
<style>
a {
    text-decoration: none;
}

a:hover {
    text-decoration: none;
}

a:focus {
    text-decoration: none;
}
#singleQuesTitle{
background:transparent;
color:black;
padding:0px;
font-size:20px;}

#singleQuesTitle:hover{
color:#34dddd;
}

#singleQuesTitle:focus{
color:#34dddd;
}
.question-author-img:hover span:before {
    opacity: 0.7;
    filter: alpha(opacity=70);
    content: "";
    font-family: "FontAwesome";
}

.navi {
    float: right;
}

.navi>ul li {
    float: left;
    line-height: 1;
    position: relative;
    height: 100%;
    font-size: 14px;
    font-weight: bold;
    margin-top: 25px;
    margin-right: 5px;
}

.navi>ul>li>a {
    display: block;
    position: relative;
    float: left;
    padding: 0 9px;
	color:white;
    line-height: 36px;
    -moz-border-radius: 5px;
    -webkit-border-radius: 5px;
    border-radius: 5px;
	cursor:pointer;
	border:solid;
	border-width:1px;
}
.navi>ul>li>a:hover {
    color:#34dddd;
    background-color:white;
	}



</style>
</head>

<body>

<div class="loader"><div class="loader_html"></div></div>
<div id="wrap" class="grid_1200">
<!-------------------------------   Header       -------------------------------------->
<header id="header" style="background:#34dddd" class=""  >
<section class="container clearfix" >
<div class="logo"><a style="cursor:pointer" onclick="window.history.back()"><img alt="" src="images/logo.png"></a></div>
<div class="navi"  >
<ul class=""><li class=""><a onclick="window.history.back()">Go Back</a></li></ul>
</div>
</section>
</header>
 
<div id="search-panel" class="section-warp zapsar" style="background:#34dddd">
<div class="container clearfix">
<div class="box_icon box_warp box_no_border box_no_background" box_border="transparent" box_background="transparent" box_color="#FFF">
<div class="site-header__search" style="margin-bottom:60px;">
                    <div class="">
                        <h3 class="site-header__title" style="text-align:center;color:white;">We built the Zapsar together...</h3>
						   </div>
                </div>

</div> 
</div> 
</div> 


<section class="container main-content page-full-width">
<div class="row">
<div class="contact-us">

<div class="col-md-3">
<div class="page-content">
<div class="question-author" style="position:absolute;margin:auto;top:20px;left:0;right:0px;width:150px;height:150px;">
<a  original-title="Member 1" class="question-author-img tooltip-n"><span></span><img alt="" src="images/member1.jpg" style="width:145px;height:144px"></a>
</div>
<h4 style="text-align:center;margin-top:170px">DANISH RABBANI</h4>
<h5 style="text-align:center">(INITIATOR)</h5>
<h2></h2>
<p style="text-align:center">Engineering Professional, believes in <br>"You can't do only those things, which You don't want to" </p>
<div class="widget widget_contact">
<ul>
<li><i class="icon-envelope-alt"></i>E-mail :<p>danish@zapsar.com</p></li>
</ul>
</div>
</div> 
</div> <div class="col-md-3">
<div class="page-content">
<div class="question-author" style="position:absolute;margin:auto;top:20px;left:0;right:0px;width:150px;height:150px;">
<a  original-title="Member 2" class="question-author-img tooltip-n"><span></span><img alt="" src="images/member2.jpg" style="width:145px;height:144px"></a>
</div>
<h4 style="text-align:center;margin-top:170px">ARSHI RABBANI</h4>
<h5 style="text-align:center">(DESIGNER)</h5>
<h2></h2>
<p style="text-align:center">A Business Intelligence Developer,<br>"That one kick is needed to drive you crazy to the extent of infinity"</p>
<div class="widget widget_contact">
<ul>
<li><i class="icon-envelope-alt"></i>E-mail :<p>arshi@zapsar.com</p></li>
</ul>
</div>
</div> 
</div>
<div class="col-md-3">
<div class="page-content">
<div class="question-author" style="position:absolute;margin:auto;top:20px;left:0;right:0px;width:150px;height:150px;">
<a  original-title="Member 3" class="question-author-img tooltip-n"><span></span><img alt="" src="images/member3.jpg" style="width:145px;height:144px"></a>
</div>
<h4 style="text-align:center;margin-top:170px">PARAS DWIVEDI</h4>
<h5 style="text-align:center">(DEVELOPER)</h5>
<h2></h2>
<p style="text-align:center">Data Science & Engineering,<br>"It's never too late to return to your dreams" </p>
<div class="widget widget_contact">
<ul>
<li><i class="icon-envelope-alt"></i>E-mail :<p>paras@zapsar.com</p></li>
</ul>
</div>
</div> 
</div><div class="col-md-3">
<div class="page-content">
<div class="question-author" style="position:absolute;margin:auto;top:20px;left:0;right:0px;width:150px;height:150px;">
<a  original-title="Member 4" class="question-author-img tooltip-n"><span></span><img alt="" src="images/member4.jpg"style="width:145px;height:144px"></a>
</div>
<h4 style="text-align:center;margin-top:170px">ABHIJEET SINGH</h4>
<h5 style="text-align:center">(DEVELOPER)</h5>
<h2></h2>
<p style="text-align:center">Web & Cloud Developer,<br>"It always seems impossible, until it is done"<sub> -Nelson Mandela</sub></p>
<div class="widget widget_contact">
<ul>
<li><i class="icon-envelope-alt"></i>E-mail :<p>abhijeet@zapsar.com</p></li>
</ul>
</div>
</div> 
</div>
</div> 
</div> 
</section> 
 
<footer id="footer">
<section class="container">
<div class="row">
<div class="col-md-6">
<div class="widget widget_contact">
<h3 class="widget_title" >About Us</h3>
<p><?php echo $c_about;?></p>
</div>
</div>
<div class="col-md-6">
<div class="widget widget_contact">
<ul>
<li>
<span style="color:#fff">Support :</span>Contact No. : <?php echo $c_phone;?>
</li>
<li>Email : <?php echo $c_email;?></li>
</ul>
</div>
</div>
</div> 
</section> 
</footer> 
<footer id="footer-bottom">
<section class="container">
<div class="copyrights f_left">Copyright &#169 2017 Zapsar</div>
<div class="social_icons f_right">
<ul>
<li class="twitter"><a href="<?php echo $c_twitter;?>" target="_blank" original-title="Twitter" class="tooltip-n" ><i class="social_icon-twitter font17"></i></a></li>
<li class="facebook"><a href="<?php echo $c_facebook;?>" target="_blank" original-title="Facebook" class="tooltip-n" ><i class="social_icon-facebook font17"></i></a></li>
<li class="youtube"><a href="<?php echo $c_youtube;?>" target="_blank" original-title="Youtube" class="tooltip-n" ><i class="social_icon-youtube font17"></i></a></li>
<li class="linkedlin"><a href="<?php echo $c_linkedin;?>" target="_blank" original-title="Linkedin" class="tooltip-n" ><i class="social_icon-linkedin font17"></i></a></li>
</ul>
</div> 
</section> 
</footer> 
</div> 
<div class="go-up"><i class="icon-chevron-up"></i></div>
 
<script src="js/jquery-ui-1.10.3.custom.min.js"></script>
<script src="js/jquery.easing.1.3.min.js"></script>
<script src="js/html5.js"></script>
<script src="js/jquery.tweet.js"></script>
<script src="js/jflickrfeed.min.js"></script>
<script src="js/jquery.inview.min.js"></script>
<script src="js/jquery.tipsy.js"></script>
<script src="js/tabs.js"></script>
<script src="js/jquery.flexslider.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>
<script src="js/jquery.carouFredSel-6.2.1-packed.js"></script>
<script src="js/jquery.scrollTo.js"></script>
<script src="js/jquery.nav.js"></script>
<script src="js/tags.js"></script>
<script src="js/jquery.bxslider.min.js"></script>
<script src="js/custom.js"></script>
 <script>
$(function(){$('[data-toggle="popover"]').popover()})
</script>
</body>
</html>