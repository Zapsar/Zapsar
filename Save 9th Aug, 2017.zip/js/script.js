function validate_login(){
var uname=document.getElementById("uname").value;
var pswd=document.getElementById("pswd").value;
if(uname=""&&pswd=""){
alert("Username & Password fields are empty.");
}else if(uname=""){
alert("Username field empty.");
}else if(pswd=""){
alert("Password field empty.");
}else{
document.getElementById("login_form").action="validate.php";
}
}
