﻿<?php
session_start();
if(!isset($_SESSION["auth_uname"])){
?>
<script>location.href="index.php"</script>
<?php
}else{
$uname=$_SESSION["auth_uname"];
}
include("stats.php");
include("creds.php");
include("contact_details.php");
error_reporting(E_ALL & ~E_NOTICE);

?>
<!DOCTYPE html>
<html lang="en">
<head>
 
<meta charset="utf-8">
<title>Zapsar – We Have Answers</title>
<meta name="description" content="Zapsar We Have Answers">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
<meta name="author" content="abhi@tech">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="css/skins.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="shortcut icon" href="images/favicon.png">
<link rel="stylesheet" href="custom_style.css">
<script src="static_tags.js"></script>

<script src="js/jquery.js"></script>
<script src="js/jquery.min.js"></script>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-6929445640060584",
    enable_page_level_ads: true
  });
</script>

<!--Pre Color:#ff7361-->
<style>
a {
    text-decoration: none;
}

a:hover {
    text-decoration: none;
}

a:focus {
    text-decoration: none;
}

#singleQuesTitle{
background:transparent;
color:black;
padding:0px;
font-size:20px;}

#singleQuesTitle:hover{
color:#34dddd;
}

#singleQuesTitle:focus{
color:#34dddd;
}
.question-author-img:hover span:before {
    opacity: 0.7;
    filter: alpha(opacity=70);
    content: "";
    font-family: "FontAwesome";
}

</style>
</head>

<body>
<div class="loader"><div class="loader_html"></div></div>
<div id="wrap" class="grid_1200">
<!--------------------------------------------- Header   ------------------------------------------>
<header id="header" style="background:#34dddd">
<section class="container clearfix" >
<a href="index_private.php">
<span class="zapsar-logo-big" style="">Z</span>
<span class="zapsar-logo">APS</span>
<span class="zapsar-logo-big">A</span>
<span class="zapsar-logo">R</span>
</a>
<div class="logo"></div>
<script type="text/javascript">
$(document).ready(function(){
var dy_tags="";
for(var i=0;i<static_tags.length;i++){
dy_tags+="<li><a>"+static_tags[i]+"</a></li>";
}

if($(window).width() <=990 && $(window).width() >=768){
$("#nav_dummy").replaceWith('<nav id="menu_list" class="navigation" style="position:absolute;top:25px;right:5px"><ul style="margin-top:10px;margin-left:-160px;width:160px"><li class="current_page_item"><a href="index_private.php">Home</a></li><li style="cursor:pointer"><a>Tags</a><ul id="tag_list">'+dy_tags+'</ul><form id="nav_tag_search" action="cat_question_private.php" method="post" style="width:0px;height:0px"><input type="hidden" name="tag_filter" id="tag_filter_input"></form></li><li><a href="ask_question.php">Ask Question</a></li><li><a style="cursor:pointer">User Profile</a><ul><li><a href="user_questions.php">Questions</a></li><li><a href="user_answers.php">Answers</a></li><li><a href="user_favorite_questions.php">Favorite Questions</a></li><li><a href="user_points.php">Points</a></li><li><a href="user_profile.php">View Profile</a></li><li><a href="edit_profile.php">Edit Profile</a></li></ul></li><li><a href="contact_us_private.php">Contact Us</a></li><li><a style="cursor:pointer" href="finish_session.php" role="button" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="<?php echo "Hi! ".$_SESSION["auth_uname"];?>">Logout</a></li></ul></nav>');
}else if($(window).width() <768){
var mar=$(window).width();
mar=mar-160;
$("#nav_dummy").replaceWith('<nav id="menu_list" class="navigation" style="position:absolute;top:25px;right:5px"><ul style="margin-top:10px;margin-left:'+mar+'px;width:160px"><li class="current_page_item"><a href="index_private.php">Home</a></li><li style="cursor:pointer"><a>Tags</a><ul id="tag_list">'+dy_tags+'</ul><form id="nav_tag_search" action="cat_question_private.php" method="post" style="width:0px;height:0px"><input type="hidden" name="tag_filter" id="tag_filter_input"></form></li><li><a href="ask_question.php">Ask Question</a></li><li><a style="cursor:pointer">User Profile</a><ul><li><a href="user_questions.php">Questions</a></li><li><a href="user_answers.php">Answers</a></li><li><a href="user_favorite_questions.php">Favorite Questions</a></li><li><a href="user_points.php">Points</a></li><li><a href="user_profile.php">View Profile</a></li><li><a href="edit_profile.php">Edit Profile</a></li></ul></li><li><a href="contact_us_private.php">Contact Us</a></li><li><a style="cursor:pointer" href="finish_session.php" role="button" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="<?php echo "Hi! ".$_SESSION["auth_uname"];?>">Logout</a></li></ul></nav>');
}else{
$("#nav_dummy").replaceWith('<nav id="menu_list" class="navigation"  ><ul class=""><li class="current_page_item"><a href="index_private.php">Home</a></li><li style="cursor:pointer"><a>Tags</a><ul id="tag_list">'+dy_tags+'</ul><form id="nav_tag_search" action="cat_question_private.php" method="post" style="width:0px;height:0px"><input type="hidden" name="tag_filter" id="tag_filter_input"></form></li><li><a href="ask_question.php">Ask Question</a></li><li><a style="cursor:pointer">User Profile</a><ul><li><a href="user_questions.php">Questions</a></li><li><a href="user_answers.php">Answers</a></li><li><a href="user_favorite_questions.php">Favorite Questions</a></li><li><a href="user_points.php">Points</a></li><li><a href="user_profile.php">View Profile</a></li><li><a href="edit_profile.php">Edit Profile</a></li></ul></li><li><a href="contact_us_private.php">Contact Us</a></li><li><a style="cursor:pointer" href="finish_session.php" role="button" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="<?php echo "Hi! ".$_SESSION["auth_uname"];?>">Logout</a></li></ul></nav>');
}
$("#tag_list li").click(function(evt){
document.getElementById("tag_filter_input").value=evt.target.innerHTML;
document.getElementById("nav_tag_search").submit();
});
});
</script>
<div id="nav_dummy"></div>
</section> 
</header> 
<script>
$('body').click(function(e){
if(e.target.id=="menu_list"||$(e.target).attr('class')=="navigation_mobile_click" || $(e.target).parents("#menu_list").length>0){
return;
}else{
if (jQuery(".navigation_mobile_click").hasClass("navigation_mobile_click_close")) {
                jQuery(".navigation_mobile_click").next().slideUp(500);
                jQuery(".navigation_mobile_click").removeClass("navigation_mobile_click_close");
            } 
}
});
</script>


<div class="breadcrumbs">
<section class="container">
<div class="row">
<div class="col-md-12">
<h1>Contact Us</h1>
</div>
<div class="col-md-12">
<div class="crumbs">
<a href="index_private.php">Home</a>
<span class="crumbs-span">/</span>
<span class="current">Contact Us</span>
</div>
</div>
</div> 
</section> 
</div> 
<section class="container main-content page-full-width">
<div class="row">
<div class="contact-us">
<div class="col-md-7">
<div class="page-content">
<h2>We would love to listen to you</h2>
<p>If you have any queries or ideas, don't hesitate to write us</p>
<form class="form-style form-style-3 form-style-5" action="send_email.php" method="post">
<div class="form-inputs clearfix">
<p>
<label for="name" class="required">Name<span>*</span></label>
<input type="text" class="required-item" value="" name="name" id="name" aria-required="true">
</p>
<p>
<label for="mail" class="required">E-Mail<span>*</span></label>
<input type="email" class="required-item" id="mail" name="email" value="" aria-required="true">
</p>
<p>
<label for="url" class="required">Subject<span>*</span></label>
<input type="text" id="url" name="subject" value="">
</p>
</div>
<div class="form-textarea">
<p>
<label for="message" class="required">Message<span>*</span></label>
<textarea id="message" class="required-item" name="message" aria-required="true" cols="58" rows="7"></textarea>
</p>
</div>
<p class="form-submit" >
<input name="submit" type="submit" value="Send" class="submit button small color" style="margin-top:3px">
</p>
</form>
</div> 
</div> 
<div class="col-md-5">
<div class="page-content">
<h2>About Us</h2>
<p><?php echo $c_about;?></p>
<div class="widget widget_contact">
<ul>
<li><i class="icon-map-marker"></i>Address :<p><?php echo $c_address;?></p></li>
<li><i class="icon-phone"></i>Contact number :<p><?php echo $c_phone;?></p></li>
<li><i class="icon-envelope-alt"></i>E-mail :<p><?php echo $c_email;?></p></li>
<li><i class="icon-user"></i>Our Team :<p><a href="#zapsarteam">Meet Our Team</a></p></li>
<li>
<i class="icon-share"></i>Social links :
<p>
<a href="<?php echo $c_facebook;?>" target="_blank" original-title="Facebook" class="tooltip-n">
<span class="icon_i">
<span class="icon_square" icon_size="25" span_bg="#3b5997" span_hover="#2f3239">
<i i_color="#FFF" class="social_icon-facebook"></i>
</span>
</span>
</a>
<a href="<?php echo $c_twitter;?>" target="_blank" original-title="Twitter" class="tooltip-n">
<span class="icon_i">
<span class="icon_square" icon_size="25" span_bg="#00baf0" span_hover="#2f3239">
<i i_color="#FFF" class="social_icon-twitter"></i>
</span>
</span>
</a>
<a href="<?php echo $c_youtube;?>" target="_blank" original-title="Youtube" class="tooltip-n" >
<span class="icon_i">
<span class="icon_square" icon_size="25" span_bg="#cc291f" span_hover="#2f3239">
<i i_color="#FFF" class="social_icon-youtube"></i>
</span>
</span>
</a>
<a href="<?php echo $c_linkedin;?>" target="_blank" original-title="Linkedin" class="tooltip-n">
<span class="icon_i">
<span class="icon_square" icon_size="25" span_bg="#006599" span_hover="#2f3239">
<i i_color="#FFF" class="social_icon-linkedin"></i>
</span>
</span>
</a>
</p>
</li>
</ul>
</div>
</div>
</div> 
</div> 
</div> 
<a id="zapsarteam"></a>
<div class="row" style="margin-top:30px;">
<div class="col-md-12" >
<div class="page-content" style="">
<h3 style="text-align:center;">We built the Zapsar together...</h3>
</div>
</div>
</div>

<div class="row" style="margin-top:30px;">
<div class="contact-us">
<div class="col-md-3">
<div class="page-content">
<div class="question-author" style="position:absolute;margin:auto;top:20px;left:0;right:0px;width:150px;height:150px;">
<a  original-title="Member 1" class="question-author-img tooltip-n"><span></span><img alt="" src="images/member1.jpg" style="width:145px;height:144px"></a>
</div>
<h4 style="text-align:center;margin-top:170px">DANISH RABBANI</h4>
<h5 style="text-align:center">(INITIATOR)</h5>
<h2></h2>
<p style="text-align:center">Engineering Professional,<br>"You can't do only those things, which You don't want to" </p>
<div class="widget widget_contact">
<ul>
<li><i class="icon-envelope-alt"></i>E-mail :<p>danish@zapsar.com</p></li>
</ul>
</div>
</div> 
</div> <div class="col-md-3">
<div class="page-content">
<div class="question-author" style="position:absolute;margin:auto;top:20px;left:0;right:0px;width:150px;height:150px;">
<a  original-title="Member 2" class="question-author-img tooltip-n"><span></span><img alt="" src="images/member2.jpg" style="width:145px;height:144px"></a>
</div>
<h4 style="text-align:center;margin-top:170px">ARSHI RABBANI</h4>
<h5 style="text-align:center">(DESIGNER)</h5>
<h2></h2>
<p style="text-align:center">Business Intelligence Developer,<br>"That one kick is needed to drive you crazy to the extent of infinity"</p>
<div class="widget widget_contact">
<ul>
<li><i class="icon-envelope-alt"></i>E-mail :<p>arshi@zapsar.com</p></li>
</ul>
</div>
</div> 
</div>
<div class="col-md-3">
<div class="page-content">
<div class="question-author" style="position:absolute;margin:auto;top:20px;left:0;right:0px;width:150px;height:150px;">
<a  original-title="Member 3" class="question-author-img tooltip-n"><span></span><img alt="" src="images/member3.jpg" style="width:145px;height:144px"></a>
</div>
<h4 style="text-align:center;margin-top:170px">PARAS DWIVEDI</h4>
<h5 style="text-align:center">(DEVELOPER)</h5>
<h2></h2>
<p style="text-align:center">Data Science & Engineering,<br>"It's never too late to return to your dreams" </p>
<div class="widget widget_contact">
<ul>
<li><i class="icon-envelope-alt"></i>E-mail :<p>paras@zapsar.com</p></li>
</ul>
</div>
</div> 
</div><div class="col-md-3">
<div class="page-content">
<div class="question-author" style="position:absolute;margin:auto;top:20px;left:0;right:0px;width:150px;height:150px;">
<a  original-title="Member 4" class="question-author-img tooltip-n"><span></span><img alt="" src="images/member4.jpg"style="width:145px;height:144px"></a>
</div>
<h4 style="text-align:center;margin-top:170px">ABHIJEET SINGH</h4>
<h5 style="text-align:center">(DEVELOPER)</h5>
<h2></h2>
<p style="text-align:center">Web & Cloud Developer,<br>"It always seems impossible, until it is done"<sub> -Nelson Mandela</sub></p>
<div class="widget widget_contact">
<ul>
<li><i class="icon-envelope-alt"></i>E-mail :<p>abhijeet@zapsar.com</p></li>
</ul>
</div>
</div> 
</div>
</div> 
</div> 

</section> 
 
<footer id="footer">
<section class="container">
<div class="row">
<div class="col-md-4">
<div class="widget widget_contact">
<h3 class="widget_title" >About Us</h3>
<p><?php echo $c_about;?></p>
<ul>
<li>
<span style="color:#fff">Support :</span>Contact No. : <?php echo $c_phone;?>
</li>
<li>Email : <?php echo $c_email;?></li>
<li><a href="terms.html" style="cursor:pointer" target="_blank">Site Terms</a> | <a href="privacy.html" style="cursor:pointer" target="_blank">Privacy Policy</a></li>
</ul>
</div>
</div>
<div class="col-md-2">
<div class="widget">
<h3 class="widget_title">Quick Links</h3>
<ul>
<li><a href="index_private.php">Home</a></li>
<li><a href="ask_question.php">Ask Question</a></li>
<li><a href="user_profile.php">View Profile</a></li>
<li><a href="edit_profile.php">Edit Profile</a></li>
<li><a href="user_questions.php">User Questions</a></li>
<li><a href="user_answers.php">User Answers</a></li>
<li><a href="user_favorite_questions.php">Favorite Questions</a></li>
<li><a href="user_points.php">User Points</a></li>
<li><a href="contact_us_private.php">Contact Us</a></li>
</ul>
</div>
</div>
<div class="col-md-3">
<div class="widget">
<h3 class="widget_title">Popular Questions</h3>
<ul class="related-posts">
<?php 
$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
?>
<script type="text/javascript">
alert("We're having some problem with our servers.");
</script>
<?php
}
else{
$rs=mysqli_query($con,"select AES_DECRYPT(username,'".$mysql_key."') as 'username',qid,title,details,attachment,tag,custom_tags,status,views,post_date from questions_table order by views DESC limit 2;");
if(mysqli_num_rows($rs)>0){
while($data=mysqli_fetch_array($rs,MYSQLI_ASSOC)){
$title=$data["title"];
$title=htmlentities($title,ENT_QUOTES);
$qid=$data["qid"];
$details=$data["details"];
$details=htmlentities($details,ENT_QUOTES);
$author=$data["username"];
$status=$data["status"];
$custom_tags=$data["custom_tags"];
$tag=$data["tag"];
$views=$data["views"];
$post_date=$data["post_date"];
$attachment=$data["attachment"];
$fav=getFavQuestionStatus($qid);

$res=mysqli_query($con,"select count('".$qid."') as 'count' from answer_table where qid='".$qid."';");
$result=mysqli_fetch_array($res,MYSQLI_ASSOC);
$answers=$result["count"];

$pres=mysqli_query($con,"select photo from user_profile where username=AES_ENCRYPT('".$author."','".$mysql_key."');");
if(mysqli_num_rows($pres)>0){
$pdata=mysqli_fetch_array($pres,MYSQLI_ASSOC);
$picture=$pdata["photo"];
}else{
$picture="avatar.png";
}
if($picture==""){
$picture="avatar.png";
}
?>
<form action="single_question_private.php" method="POST">
<li class="related-item">
<h3><input id="singleQuesTitle" style="font-size:15px;color:white;padding-bottom:5px" type="submit" value="<?php echo substr($title,0,30)."...";?>" ></h3>
<p><?php echo substr($details,0,60)."...";?></p>
<div class="clear"></div><span><?php echo getRegDate($post_date);?></span>
</li>
<input type="hidden" name="single_ques_pri_title" value="<?php echo $title;?>">
<input type="hidden" name="single_ques_pri_id" value="<?php echo $qid;?>">
<input type="hidden" name="single_ques_pri_details" value="<?php echo $details;?>">
<input type="hidden" name="single_ques_pri_author" value="<?php echo $author;?>">
<input type="hidden" name="single_ques_pri_status" value="<?php echo $status;?>">
<input type="hidden" name="single_ques_pri_answers" value="<?php echo $answers;?>">
<input type="hidden" name="single_ques_pri_fav" value="<?php echo $fav;?>">
<input type="hidden" name="single_ques_pri_custom_tags" value="<?php echo $custom_tags;?>">
<input type="hidden" name="single_ques_pri_tag" value="<?php echo $tag;?>">
<input type="hidden" name="single_ques_pri_views" value="<?php echo $views;?>">
<input type="hidden" name="single_ques_pri_picture" value="<?php echo $picture;?>">
<input type="hidden" name="single_ques_pri_post_date" value="<?php echo $post_date;?>">
<input type="hidden" name="single_ques_pri_attachment" value="<?php echo $attachment;?>">
<input type="hidden" name="through_post_method" value="true">
</form>

<?php
}
}
mysqli_close($con);
}
?>
</ul>
</div>
</div>
<div class="col-md-3">
<div class="widget">
<h3 class="widget_title">Frequent Tags</h3>
<div class="related-item" id="freq_tag_div">
<?php 
$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
?>
<script type="text/javascript">
alert("We're having some problem with our servers.");
</script>
<?php
}
else{
$rs=mysqli_query($con,"select count(tag),tag from questions_table group by tag order by count(tag) DESC limit 30;");
if(mysqli_num_rows($rs)>0){
$ci=0;
while($data=mysqli_fetch_array($rs,MYSQLI_ASSOC)){
if($ci==0){
echo '<a style="cursor:pointer">'.ucwords($data['tag']).'</a>';
$ci++;
}else{
echo ', <a style="cursor:pointer">'.ucwords($data['tag']).'</a>';
}
}
echo '<form id="freq_tag_form" action="cat_question_private.php" method="post" style="width:0px;height:0px">
<input type="hidden" name="tag_filter" id="freq_tag_filter">
</form>';
}
mysqli_close($con);
}
?>
<script type="text/javascript">
$("#freq_tag_div a").click(function(evt){
document.getElementById("freq_tag_filter").value=evt.target.innerHTML;
document.getElementById("freq_tag_form").submit();
});
</script>

</div>
</div>
</div>
</div>  
</section> 
</footer> 
<footer id="footer-bottom">
<section class="container">
<div class="copyrights f_left">Copyright &#169 2017 Zapsar</div>
<div class="social_icons f_right">
<ul>
<li class="twitter"><a href="<?php echo $c_twitter;?>" target="_blank" original-title="Twitter" class="tooltip-n" ><i class="social_icon-twitter font17"></i></a></li>
<li class="facebook"><a href="<?php echo $c_facebook;?>" target="_blank" original-title="Facebook" class="tooltip-n" ><i class="social_icon-facebook font17"></i></a></li>
<li class="youtube"><a href="<?php echo $c_youtube;?>" target="_blank" original-title="Youtube" class="tooltip-n" ><i class="social_icon-youtube font17"></i></a></li>
<li class="linkedlin"><a href="<?php echo $c_linkedin;?>" target="_blank" original-title="Linkedin" class="tooltip-n" ><i class="social_icon-linkedin font17"></i></a></li>
</ul>
</div> 
</section> 
</footer> 
</div> 
<div class="go-up"><i class="icon-chevron-up"></i></div>
 
<script src="bootstrap/js/bootstrap.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery-ui-1.10.3.custom.min.js"></script>
<script src="js/jquery.easing.1.3.min.js"></script>
<script src="js/html5.js"></script>
<script src="js/twitter/jquery.tweet.js"></script>
<script src="js/jflickrfeed.min.js"></script>
<script src="js/jquery.inview.min.js"></script>
<script src="js/jquery.tipsy.js"></script>
<script src="js/tabs.js"></script>
<script src="js/jquery.flexslider.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>
<script src="js/jquery.carouFredSel-6.2.1-packed.js"></script>
<script src="js/jquery.scrollTo.js"></script>
<script src="js/jquery.nav.js"></script>
<script src="js/tags.js"></script>
<script src="js/jquery.bxslider.min.js"></script>
<script src="js/custom.js"></script>
 <script>
$(function(){$('[data-toggle="popover"]').popover({container:'body'})})
</script>

 
</body>
</html>