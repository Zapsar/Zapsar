<?php
include("creds.php");
error_reporting(E_ALL & ~E_NOTICE);

$token=$_GET["token_id"];
$token_qid="Q".substr($token,0,strpos($token,"sha256"));
$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
echo '<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap/css/bootstrap.css" >
<script src="js/jquery.js" ></script>
<script src="bootstrap/js/bootstrap.js" ></script>
</head>
<body onclick="location.href=\'index.php\'">
<div id="show_alert" class="modal fade" role="dialog">
  <div class="modal-dialog" role="document">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">SERVER PROBLEM</h4>
      </div>
      <div class="modal-body">
	 <div class="alert alert-info alert-dismissible fade in" role="alert" style="margin-top:0px">
<span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span><strong> Oh Snap! </strong>We are having problem with our server, Please try again... 
</div>
<div class="alert alert-info alert-dismissible fade in" role="alert" style="margin-top:0px">
If Confirm Form Resubmission page occurs, try to reload again. <span class="glyphicon glyphicon-refresh" aria-hidden="true"></span>
</div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
$("#show_alert").modal();
</script>
</body></html>';
}else{

$rs=mysqli_query($con,"select AES_DECRYPT(username,'".$mysql_key."') as 'username',qid,title,details,attachment,tag,custom_tags,status,views,post_date from questions_table where qid='".$token_qid."' ;");

if($data=mysqli_fetch_array($rs,MYSQLI_ASSOC)){
$title=$data["title"];
$title=htmlentities($title,ENT_QUOTES);
$qid=$data["qid"];
$details=$data["details"];
$details=htmlentities($details,ENT_QUOTES);
$author=$data["username"];
$status=$data["status"];
$custom_tags=$data["custom_tags"];
$tag=$data["tag"];
$post_date=$data["post_date"];
$views=$data["views"];
$attachment=$data["attachment"];

$res=mysqli_query($con,"select count('".$qid."') as 'count' from answer_table where qid='".$qid."';");
$result=mysqli_fetch_array($res,MYSQLI_ASSOC);
$answers=$result["count"]; 

$pres=mysqli_query($con,"select photo from user_profile where username=AES_ENCRYPT('".$author."','".$mysql_key."');");
if(mysqli_num_rows($pres)>0){
$pdata=mysqli_fetch_array($pres,MYSQLI_ASSOC);
$picture=$pdata["photo"];
}else{
$picture="avatar.png";
}
if($picture==""){
$picture="avatar.png";
}

session_start();
if(!isset($_SESSION["auth_uname"])){
echo '
<html>
<body>
<form id="share_form" action="single_question.php" method="POST">
<input type="hidden" name="single_ques_title" value="'.$title.'">
<input type="hidden" name="single_ques_id" value="'.$qid.'">
<input type="hidden" name="single_ques_details" value="'.$details.'">
<input type="hidden" name="single_ques_author" value="'.$author.'">
<input type="hidden" name="single_ques_status" value="'.$status.'">
<input type="hidden" name="single_ques_answers" value="'.$answers.'">
<input type="hidden" name="single_ques_custom_tags" value="'.$custom_tags.'">
<input type="hidden" name="single_ques_tag" value="'.$tag.'">
<input type="hidden" name="single_ques_picture" value="'.$picture.'">
<input type="hidden" name="single_ques_attachment" value="'.$attachment.'">
<input type="hidden" name="single_ques_post_date" value="'.$post_date.'">
</form>
<script>
document.getElementById("share_form").submit();
</script>
</body>
</html>';

}else if(isset($_SESSION["auth_uname"])){
echo '
<html>
<body>
<form id="share_form" action="single_question_private.php" method="POST">
<input type="hidden" name="single_ques_pri_title" value="'.$title.'">
<input type="hidden" name="single_ques_pri_id" value="'.$qid.'">
<input type="hidden" name="single_ques_pri_details" value="'.$details.'">
<input type="hidden" name="single_ques_pri_author" value="'.$author.'">
<input type="hidden" name="single_ques_pri_status" value="'.$status.'">
<input type="hidden" name="single_ques_pri_answers" value="'.$answers.'">
<input type="hidden" name="single_ques_pri_fav" value="'.$fav.'">
<input type="hidden" name="single_ques_pri_custom_tags" value="'.$custom_tags.'">
<input type="hidden" name="single_ques_pri_tag" value="'.$tag.'">
<input type="hidden" name="single_ques_pri_views" value="'.$views.'">
<input type="hidden" name="single_ques_pri_picture" value="'.$picture.'">
<input type="hidden" name="single_ques_pri_post_date" value="'.$post_date.'">
<input type="hidden" name="single_ques_pri_attachment" value="'.$attachment.'">
<input type="hidden" name="through_post_method" value="true">
</form>
<script>
document.getElementById("share_form").submit();
</script>
</body>
</html>';

}
}else{
session_start();
if(!isset($_SESSION["auth_uname"])){
?>
<script>location.href="index.php"</script>
<?php
}else if(isset($_SESSION["auth_uname"])){
?>
<script>location.href="index_private.php"</script>
<?php
}
}
}
?>