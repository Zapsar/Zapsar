<?php
include("creds.php");
include("stats.php");

session_start();

$username=$_POST["author"];
$email=$_POST["email"];
$answer=$_POST["comment"];
$qid=$_POST["single_ques_id"];

if($username==""||$email==""||$answer==""){
echo '<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap/css/bootstrap.css" >
<script src="js/jquery.js" ></script>
<script src="bootstrap/js/bootstrap.js" ></script>
</head>
<body onclick="window.history.back();">
<div id="show_alert" class="modal fade" role="dialog">
  <div class="modal-dialog" role="document">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">EMPTY FIELDS</h4>
      </div>
      <div class="modal-body">
	 <div class="alert alert-danger alert-dismissible fade in" role="alert" style="margin-top:0px">
<span class="glyphicon glyphicon-remove-sign" aria-hidden="true"></span><strong> Important! </strong>Required fields are empty. 
</div>
<div class="alert alert-info alert-dismissible fade in" role="alert" style="margin-top:0px">
If Confirm Form Resubmission page occurs, try to reload again. <span class="glyphicon glyphicon-refresh" aria-hidden="true"></span>
</div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
$("#show_alert").modal();
</script>
</body></html>';
}else if(!preg_match('/[A-Za-z]/',$answer)){
echo '<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap/css/bootstrap.css">
<script src="js/jquery.js" ></script>
<script src="bootstrap/js/bootstrap.js" ></script>
</head>
<body onclick="window.history.back();">
<div id="show_alert" class="modal fade" role="dialog">
  <div class="modal-dialog" role="document">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">ANSWER TOO SHORT</h4>
      </div>
      <div class="modal-body">
	 <div class="alert alert-danger alert-dismissible fade in" role="alert" style="margin-top:0px">
<span class="glyphicon glyphicon-remove-sign" aria-hidden="true"></span><strong> Important! </strong>Your answer does not contain any alphabets, please provide a brief explanation if your answer is too short. 
</div>
<div class="alert alert-info alert-dismissible fade in" role="alert" style="margin-top:0px">
If Confirm Form Resubmission page occurs, try to reload again. <span class="glyphicon glyphicon-refresh" aria-hidden="true"></span>
</div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
$("#show_alert").modal();
</script>
</body></html>';
}else{
$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
echo '<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap/css/bootstrap.css" >
<script src="js/jquery.js" ></script>
<script src="bootstrap/js/bootstrap.js" ></script>
</head>
<body onclick="window.history.back();">
<div id="show_alert" class="modal fade" role="dialog">
  <div class="modal-dialog" role="document">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">SERVER PROBLEM</h4>
      </div>
      <div class="modal-body">
	 <div class="alert alert-info alert-dismissible fade in" role="alert" style="margin-top:0px">
<span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span><strong> Oh Snap! </strong>We are having problem with our server, Please try again... 
</div>
<div class="alert alert-info alert-dismissible fade in" role="alert" style="margin-top:0px">
If Confirm Form Resubmission page occurs, try to reload again. <span class="glyphicon glyphicon-refresh" aria-hidden="true"></span>
</div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
$("#show_alert").modal();
</script>
</body></html>';
}
else{
$username=strtolower($username);
$email=strtolower($email);

$username=mysqli_real_escape_string($con,$username);
$email=mysqli_real_escape_string($con,$email);
$answer=mysqli_real_escape_string($con,$answer);

$auth1=mysqli_query($con,"select email from user_creds where username=AES_ENCRYPT('".$username."','".$mysql_key."');");
if(mysqli_num_rows($auth1)>0){
$data_auth1=mysqli_fetch_array($auth1,MYSQLI_ASSOC);
if($data_auth1["email"]==$email){

if(mysqli_query($con,"insert into aids values(null);")){
$aid="";
$res=mysqli_query($con,"select aid from aids order by aid DESC limit 1;");
$data=mysqli_fetch_array($res,MYSQLI_ASSOC);
$aid=$data["aid"];

$target_dir = "attachments/";
$target_file = $target_dir . basename($_FILES["attach_file"]["name"]);
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
$attachment='n';
if (move_uploaded_file($_FILES["attach_file"]["tmp_name"],$target_dir."ans_attach-a".$aid.".".$imageFileType)) {
        $attachment= "ans_attach-a".$aid.".".$imageFileType;
    } else {
        $attachment= 'n';
    }


if(mysqli_query($con,"insert into answer_table values(null,AES_ENCRYPT('".$username."','".$mysql_key."'),CONCAT('A','".$aid."'),'".$qid."','".$answer."','".$attachment."',CONVERT_TZ(UTC_TIMESTAMP(),'+0:00','+5:30'));")){
if(mysqli_query($con,"update questions_table set status='s' where qid='".$qid."';")){
$res=mysqli_query($con,"select AES_DECRYPT(username,'".$mysql_key."') as 'username',qid,title,details,attachment,tag,custom_tags,views,post_date from questions_table where qid='".$qid."';");
$data=mysqli_fetch_array($res,MYSQLI_ASSOC);

$qid=$data["qid"];
$title=$data["title"];
$title=htmlentities($title,ENT_QUOTES);
$details=$data["details"];
$details=htmlentities($details,ENT_QUOTES);
$custom_tags=$data["custom_tags"];
$tag=$data["tag"];
$author=$data["username"];
$post_date=$data["post_date"];
$status='s';
$views=$data["views"];
$attachment=$data["attachment"];

$rs=mysqli_query($con,"select count('".$qid."') as 'count' from answer_table where qid='".$qid."';");
$data=mysqli_fetch_array($rs,MYSQLI_ASSOC);
$answers=$data["count"];

$pres=mysqli_query($con,"select photo from user_profile where username=AES_ENCRYPT('".$author."','".$mysql_key."');");
if(mysqli_num_rows($pres)>0){
$pdata=mysqli_fetch_array($pres,MYSQLI_ASSOC);
$picture=$pdata["photo"];
}else{
$picture="avatar.png";
}
if($picture==""){
$picture="avatar.png";
}


$user_points=getUserPoints($username);

$rs=mysqli_query($con,"select points from user_points where username=AES_ENCRYPT('".$username."','".$mysql_key."');");
if(mysqli_num_rows($rs)>0){
mysqli_query($con,"update user_points set points='".$user_points."' where username=AES_ENCRYPT('".$username."','".$mysql_key."');");
}else{
mysqli_query($con,"insert into user_points values(null,AES_ENCRYPT('".$username."','".$mysql_key."'),'".$user_points."');");
}

mysqli_close($con);

echo '<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap/css/bootstrap.css" >
<script src="js/jquery.js" ></script>
<script src="bootstrap/js/bootstrap.js" ></script>
</head>
<body onclick="load_page()">
<form action="single_question.php" method="post" id="post_answer_form">
<input type="hidden" name="single_ques_title" value="'.$title.'">
<input type="hidden" name="single_ques_id" value="'.$qid.'">
<input type="hidden" name="single_ques_details" value="'.$details.'">
<input type="hidden" name="single_ques_author" value="'.$author.'">
<input type="hidden" name="single_ques_status" value="'.$status.'">
<input type="hidden" name="single_ques_answers" value="'.$answers.'">
<input type="hidden" name="single_ques_custom_tags" value="'.$custom_tags.'">
<input type="hidden" name="single_ques_tag" value="'.$tag.'">
<input type="hidden" name="single_ques_picture" value="'.$picture.'">
<input type="hidden" name="single_ques_attachment" value="'.$attachment.'">
<input type="hidden" name="single_ques_post_date" value="'.$post_date.'">
</form>
<div id="show_alert" class="modal fade" role="dialog">
  <div class="modal-dialog" role="document">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">ANSWER PUBLISHED</h4>
      </div>
      <div class="modal-body">
	 <div class="alert alert-success alert-dismissible fade in" role="alert" style="margin-top:0px">
<span class="glyphicon glyphicon-success-sign" aria-hidden="true"></span><strong> AWESOME! </strong>Your answer published successfully. 
</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
$("#show_alert").modal();
function load_page(){
document.getElementById("post_answer_form").submit();
}
</script>
</body></html>';
}else{
redirect($con);
}
}else{
redirect($con);
}
}else{
redirect($con);
}
}else{
echo '<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap/css/bootstrap.css" >
<script src="js/jquery.js" ></script>
<script src="bootstrap/js/bootstrap.js" ></script>
</head>
<body onclick="window.history.back();">
<div id="show_alert" class="modal fade" role="dialog">
  <div class="modal-dialog" role="document">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">UNREGISTERED EMAIL</h4>
      </div>
      <div class="modal-body">
	 <div class="alert alert-warning alert-dismissible fade in" role="alert" style="margin-top:0px">
<span class="glyphicon glyphicon-warning-sign" aria-hidden="true"></span><strong> Important! </strong>This is not registered email, use only registered email to post answer. 
</div>
<div class="alert alert-info alert-dismissible fade in" role="alert" style="margin-top:0px">
If Confirm Form Resubmission page occurs, try to reload again. <span class="glyphicon glyphicon-refresh" aria-hidden="true"></span>
</div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
$("#show_alert").modal();
</script>
</body></html>';

}
}else{
echo '<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap/css/bootstrap.css" >
<script src="js/jquery.js" ></script>
<script src="bootstrap/js/bootstrap.js" ></script>
</head>
<body onclick="window.history.back();">
<div id="show_alert" class="modal fade" role="dialog">
  <div class="modal-dialog" role="document">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">UNREGISTERED USER</h4>
      </div>
      <div class="modal-body">
	 <div class="alert alert-warning alert-dismissible fade in" role="alert" style="margin-top:0px">
<span class="glyphicon glyphicon-warning-sign" aria-hidden="true"></span><strong> Sorry! </strong>Your are not registered user. Please, first create an account, then post your answers... 
</div>
<div class="alert alert-info alert-dismissible fade in" role="alert" style="margin-top:0px">
If Confirm Form Resubmission page occurs, try to reload again. <span class="glyphicon glyphicon-refresh" aria-hidden="true"></span>
</div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
$("#show_alert").modal();
</script>
</body></html>';

}
}
}

function redirect($con){
mysqli_close($con);
echo '<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="bootstrap/css/bootstrap.css" >
<script src="js/jquery.js" ></script>
<script src="bootstrap/js/bootstrap.js" ></script>
</head>
<body onclick="window.history.back();">
<div id="show_alert" class="modal fade" role="dialog">
  <div class="modal-dialog" role="document">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">SERVER PROBLEM</h4>
      </div>
      <div class="modal-body">
	 <div class="alert alert-info alert-dismissible fade in" role="alert" style="margin-top:0px">
<span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span><strong> Oh Snap! </strong>We are having problem with our server, Please try again... 
</div>
<div class="alert alert-info alert-dismissible fade in" role="alert" style="margin-top:0px">
If Confirm Form Resubmission page occurs, try to reload again. <span class="glyphicon glyphicon-refresh" aria-hidden="true"></span>
</div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
$("#show_alert").modal();
</script>
</body></html>';
}
?>
