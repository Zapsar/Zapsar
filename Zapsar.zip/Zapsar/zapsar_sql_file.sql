-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 23, 2017 at 06:58 AM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `zapsar`
--
CREATE DATABASE IF NOT EXISTS `zapsar` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `zapsar`;

-- --------------------------------------------------------

--
-- Table structure for table `aids`
--

CREATE TABLE IF NOT EXISTS `aids` (
  `aid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'answer id',
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='distributes answer ids' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `answer_review`
--

CREATE TABLE IF NOT EXISTS `answer_review` (
  `sno` int(11) NOT NULL AUTO_INCREMENT COMMENT 'auto incremented serial number',
  `aid` varchar(50) NOT NULL COMMENT 'answer id',
  `likes` int(11) NOT NULL DEFAULT '0' COMMENT 'likes',
  `stars` int(1) unsigned NOT NULL DEFAULT '0' COMMENT 'answer star rating, 0 1 2 3 4 5',
  PRIMARY KEY (`aid`),
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='answer review table' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `answer_table`
--

CREATE TABLE IF NOT EXISTS `answer_table` (
  `sno` int(11) NOT NULL AUTO_INCREMENT COMMENT 'auto incremented serial number',
  `username` varchar(50) NOT NULL COMMENT 'user name should be unique',
  `aid` varchar(50) NOT NULL COMMENT 'answer id',
  `qid` varchar(50) NOT NULL COMMENT 'question id',
  `answer` text NOT NULL COMMENT 'answer text',
  `attachment` varchar(100) NOT NULL DEFAULT 'NA' COMMENT 'attachment file name',
  `post_date` datetime NOT NULL COMMENT 'answer posting date time',
  PRIMARY KEY (`aid`),
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='answers table' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `qids`
--

CREATE TABLE IF NOT EXISTS `qids` (
  `qid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'question ids',
  PRIMARY KEY (`qid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `qids`
--

INSERT INTO `qids` (`qid`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12),
(13),
(14),
(15);

-- --------------------------------------------------------

--
-- Table structure for table `questions_table`
--

CREATE TABLE IF NOT EXISTS `questions_table` (
  `sno` int(11) NOT NULL AUTO_INCREMENT COMMENT 'auto incremented serial number',
  `username` varchar(50) NOT NULL COMMENT 'user name should be unique',
  `qid` varchar(50) NOT NULL COMMENT 'question id',
  `title` text NOT NULL COMMENT 'question title',
  `tag` text NOT NULL COMMENT 'tags, multiple tags are separated by comma',
  `category` varchar(50) NOT NULL COMMENT 'category',
  `details` text NOT NULL COMMENT 'question details',
  `status` char(1) NOT NULL DEFAULT 'i' COMMENT 'status, s for solved, i for in progress',
  `post_date` datetime NOT NULL COMMENT 'question posting date time',
  PRIMARY KEY (`qid`),
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='question table' AUTO_INCREMENT=6 ;

--
-- Dumping data for table `questions_table`
--

INSERT INTO `questions_table` (`sno`, `username`, `qid`, `title`, `tag`, `category`, `details`, `status`, `post_date`) VALUES
(1, 'abhi', 'Q1', 'CPU Generations', 'computer, cpu, technology, intel generations', 'technology', 'What are the families of Intel Processors and How they are different from each other. How to identify them all.', 'i', '2017-04-30 15:41:00'),
(4, 'abhi', 'Q14', 'DBMS', 'database,software', 'technology', 'What is Database and DBMS? What are different types of DBMS and databses.', 'i', '2017-04-30 16:04:10'),
(5, 'abhi', 'Q15', 'Postgraduate', 'mtech,ms,phd', 'science', 'Difference between Mtech, MS and Phd. Are they same, if different how. What is best to pursue after Btech. ', 'i', '2017-05-22 13:07:06'),
(2, 'abhi', 'Q3', 'Bootable Drive', 'boot,os', 'technology', 'How to create bootable derive for Linux and Windows Computer. ', 'i', '2017-04-30 15:55:33');

-- --------------------------------------------------------

--
-- Table structure for table `question_review`
--

CREATE TABLE IF NOT EXISTS `question_review` (
  `sno` int(11) NOT NULL AUTO_INCREMENT COMMENT 'auto incremented serial number',
  `qid` varchar(50) NOT NULL COMMENT 'question id',
  `likes` int(11) NOT NULL DEFAULT '0' COMMENT 'likes',
  `views` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'views',
  PRIMARY KEY (`qid`),
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='questions review status' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `remember_me`
--

CREATE TABLE IF NOT EXISTS `remember_me` (
  `sno` int(11) NOT NULL AUTO_INCREMENT COMMENT 'auto incremented serial number',
  `username` varchar(50) NOT NULL COMMENT 'user name should be unique',
  PRIMARY KEY (`username`),
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='remember me table, here only username can be stored' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_creds`
--

CREATE TABLE IF NOT EXISTS `user_creds` (
  `sno` int(11) NOT NULL AUTO_INCREMENT COMMENT 'auto incremented serial number',
  `username` varchar(50) NOT NULL COMMENT 'user name should be unique',
  `email` varchar(100) NOT NULL COMMENT 'email id',
  `pswd` varchar(100) NOT NULL COMMENT 'password',
  `reg_date` datetime NOT NULL COMMENT 'registration date time',
  PRIMARY KEY (`username`),
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='user credential table' AUTO_INCREMENT=6 ;

--
-- Dumping data for table `user_creds`
--

INSERT INTO `user_creds` (`sno`, `username`, `email`, `pswd`, `reg_date`) VALUES
(5, 'abhi', 'abhijeet.jeet07@gmail.com', '12345', '2017-04-28 16:09:10');

-- --------------------------------------------------------

--
-- Table structure for table `user_data`
--

CREATE TABLE IF NOT EXISTS `user_data` (
  `sno` int(11) NOT NULL AUTO_INCREMENT COMMENT 'auto incremented serial number',
  `username` varchar(50) NOT NULL COMMENT 'user name should be unique',
  `fav_questions` text COMMENT 'user''s favorite questions',
  `best_answers` text COMMENT 'user''s best answers',
  `points` int(5) NOT NULL DEFAULT '0' COMMENT 'user''s points',
  PRIMARY KEY (`username`),
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='user''s points, favorite questions, best answers' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_profile`
--

CREATE TABLE IF NOT EXISTS `user_profile` (
  `sno` int(11) NOT NULL AUTO_INCREMENT COMMENT 'auto incremented serial number',
  `username` varchar(50) NOT NULL COMMENT 'user name should be unique',
  `fname` varchar(100) DEFAULT NULL COMMENT 'first name',
  `lname` varchar(100) DEFAULT NULL COMMENT 'last name',
  `photo` varchar(100) DEFAULT NULL COMMENT 'profile photo',
  `country` varchar(50) DEFAULT NULL COMMENT 'country',
  `website` varchar(150) DEFAULT NULL COMMENT 'website link',
  `about` text COMMENT 'about me',
  `googleplus` varchar(100) DEFAULT NULL COMMENT 'google plus account link',
  `facebook` varchar(100) DEFAULT NULL COMMENT 'facebook profile link',
  `twitter` varchar(100) DEFAULT NULL COMMENT 'twitter profile link',
  `linkedin` varchar(100) DEFAULT NULL COMMENT 'linked profile link',
  `last_updated` datetime NOT NULL COMMENT 'last updated profile date time',
  PRIMARY KEY (`username`),
  UNIQUE KEY `sno` (`sno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='user profile data is stores here, this table may contain nulls' AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
