<?php
session_start();
$uname=$_SESSION["auth_uname"];

$con=mysql_connect("localhost","root","");
if(!$con){
echo "connection faiure";
}
else{
echo "connection successful";
$db=mysql_query("use zapsar",$con);
if($db){
$rs=mysql_query("insert into user_creds values(null,'".$uname."','".$email."','".$pswd."',CONCAT(CURRENT_DATE,' ',CURRENT_TIME));",$con);
if($rs){
?>
<script type="text/javascript">
location.href="edit_profile.php";
</script>
<?php
mysql_close($con);
}else{
echo "failed to failed to update user profile";
}
}
}
}
?>