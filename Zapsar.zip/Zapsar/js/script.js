function enable_pswd_fields(){
if(document.getElementById("change_pswd_chk").checked==true){
document.getElementById("pswd_field1").disabled=false;
document.getElementById("pswd_field2").disabled=false;
document.getElementById("pswd_field3").disabled=false;
document.getElementById("pswd_field1").style.background="#f3f3f3";
document.getElementById("pswd_field2").style.background="#f3f3f3";
document.getElementById("pswd_field3").style.background="#f3f3f3";
}else
if(document.getElementById("change_pswd_chk").checked==false){
document.getElementById("pswd_field1").disabled=true;
document.getElementById("pswd_field2").disabled=true;
document.getElementById("pswd_field3").disabled=true;
document.getElementById("pswd_field1").style.background="#e1e1e1";
document.getElementById("pswd_field2").style.background="#e1e1e1";
document.getElementById("pswd_field3").style.background="#e1e1e1";
}

}