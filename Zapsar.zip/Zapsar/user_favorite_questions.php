﻿<!DOCTYPE html>
<html lang="en">
<head>
 
<meta charset="utf-8">
<title>Zapsar – We Have Answers</title>
<meta name="description" content="Zapsar We Have Answers">
<meta name="author" content="abhi@tech">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="css/skins.css">
<link rel="stylesheet" href="css/responsive.css">
 
<link rel="shortcut icon" href="images/favicon.png">
<!--Pre Color:#ff7361-->
<style>
a {
    text-decoration: none;
}

a:hover {
    text-decoration: none;
}

a:focus {
    text-decoration: none;
}

</style>
</head>

<body>
<div class="loader"><div class="loader_html"></div></div>
<div id="wrap" class="grid_1200">
<!--------------------------------------------- Header   ------------------------------------------>
<header id="header" style="background:#34dddd">
<section class="container clearfix" >
<div class="logo"><a href="index_private.php"><img alt="" src="images/logo.png"></a></div>
<nav class="navigation"  >
<ul class="">
<li class="current_page_item"><a href="index_private.php">Home</a></li>
<li><a href="cat_question_private.php">Category</a><ul>
<li><a href="cat_question_private.php">Arts</a></li>
<li><a href="cat_question_private.php">Books</a></li>
<li><a href="cat_question_private.php">Business</a></li>
<li><a href="cat_question_private.php">Cooking</a></li>
<li><a href="cat_question_private.php">Fitness</a></li>
<li><a href="cat_question_private.php">Finance</a></li>
<li><a href="cat_question_private.php">Food</a></li>
<li><a href="cat_question_private.php">Science</a></li>
<li><a href="cat_question_private.php">Technology</a></li>
</ul>
</li>

<li><a href="ask_question.php">Ask Question</a></li>

<li><a href="#">User</a><ul>
<li><a href="user_questions.php">Questions</a></li>
<li><a href="user_answers.php">Answers</a></li>
<li><a href="user_favorite_questions.php">Favorite Questions</a></li>
<li><a href="user_points.php">Points</a></li>
<li><a href="user_profile.php">View Profile</a></li>
<li><a href="edit_profile.php">Edit Profile</a></li>
</ul>
</li>

<li><a href="contact_us_private.php">Contact Us</a></li>
<li><a href="finish_session.php" >Logout</a></li>
</ul>
</nav>
</section> 
</header> 

 
<div class="breadcrumbs">
<section class="container">
<div class="row">
<div class="col-md-12">
<h1>User Favorite Questions : admin</h1>
</div>
<div class="col-md-12">
<div class="crumbs">
<a href="index_private.php">Home</a>
<span class="crumbs-span">/</span>
<a href="#">User</a>
<span class="crumbs-span">/</span>
<span class="current">User Favorite Questions : admin</span>
</div>
</div>
</div> 
</section> 
</div> 
<section class="container main-content">
<div class="row">
<div class="col-md-9">
<div class="row">
<div class="user-profile">
<div class="col-md-12">
<div class="page-content">
<h2>About admin</h2>
<div class="user-profile-img"><img width="60" height="60" src="images/admin.jpeg" alt="admin"></div>
<div class="ul_list ul_list-icon-ok about-user">
<ul>
<li><i class="icon-plus"></i>Registerd : <span>Jan 10, 2017</span></li>
<li><i class="icon-map-marker"></i>Country : <span>India</span></li>
<li><i class="icon-globe"></i>Website : <a target="_blank" href="#">view</a></li>
</ul>
</div>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi adipiscing gravida odio, sit amet suscipit risus ultrices eu. Fusce viverra neque at purus laoreet consequat. Vivamus vulputate posuere nisl quis consequat. Donec congue commodo mi, sed commodo velit fringilla ac. Fusce placerat venenatis mi. Pellentesque habitant morbi tristique senectus et netus et malesuada .</p>
<div class="clearfix"></div>
<span class="user-follow-me">Follow Me</span>
<a href="#" original-title="Facebook" class="tooltip-n">
<span class="icon_i">
<span class="icon_square" icon_size="30" span_bg="#3b5997" span_hover="#2f3239">
<i class="social_icon-facebook"></i>
</span>
</span>
</a>
<a href="#" original-title="Twitter" class="tooltip-n">
<span class="icon_i">
<span class="icon_square" icon_size="30" span_bg="#00baf0" span_hover="#2f3239">
<i class="social_icon-twitter"></i>
</span>
</span>
</a>
<a href="#" original-title="Linkedin" class="tooltip-n">
<span class="icon_i">
<span class="icon_square" icon_size="30" span_bg="#006599" span_hover="#2f3239">
<i class="social_icon-linkedin"></i>
</span>
</span>
</a>
<a href="#" original-title="Google plus" class="tooltip-n">
<span class="icon_i">
<span class="icon_square" icon_size="30" span_bg="#c43c2c" span_hover="#2f3239">
<i class="social_icon-gplus"></i>
</span>
</span>
</a>
<a href="#" original-title="Email" class="tooltip-n">
<span class="icon_i">
<span class="icon_square" icon_size="30" span_bg="#000" span_hover="#2f3239">
<i class="social_icon-email"></i>
</span>
</span>
</a>
</div> 
</div> 
<div class="col-md-12">
<div class="page-content page-content-user-profile">
<div class="user-profile-widget">
<h2>User Stats</h2>
<div class="ul_list ul_list-icon-ok">
<ul>
<li><i class="icon-question-sign"></i><a href="user_questions.php">Questions<span> ( <span>30</span> ) </span></a></li>
<li><i class="icon-comment"></i><a href="user_answers.php">Answers<span> ( <span>10</span> ) </span></a></li>
<li><i class="icon-star"></i><a href="user_favorite_questions.php">Favorite Questions<span> ( <span>3</span> ) </span></a></li>
<li><i class="icon-heart"></i><a href="user_points.php">Points<span> ( <span>20</span> ) </span></a></li>
<li><i class="icon-asterisk"></i>Best Answers<span> ( <span>2</span> ) </span></li>
</ul>
</div>
</div> 
</div> 
</div> 
</div> 
</div> 
<div class="clearfix"></div>
<div class="page-content page-content-user">
<div class="user-questions">
<article class="question user-question">
<h3>
<a href="cat_question.php">This is my first Question</a>
</h3>
<div class="question-type-main"><i class="icon-question-sign"></i>Question</div>
<div class="question-content">
<div class="question-bottom">
<div class="question-answered"><i class="icon-ok"></i>in progress</div>
<span class="question-favorite"><i class="icon-star"></i>5</span>
<!--<span class="question-category"><a href="#"><i class="icon-folder-close"></i>wordpress</a></span>
--><span class="question-date"><i class="icon-time"></i>15 secs ago</span>
<span class="question-comment"><a href="#"><i class="icon-comment"></i>5 Answers</a></span>
<a class="question-reply" href="#"><i class="icon-reply"></i>Reply</a>
<span class="question-view"><i class="icon-user"></i>70 views</span>
</div>
</div>
</article>
<article class="question user-question">
<h3>
<a href="single_question_poll.php">This Is My Second Poll Question</a>
</h3>
<div class="question-type-main"><i class="icon-signal"></i>Poll</div>
<div class="question-content">
<div class="question-bottom">
<span class="question-favorite"><i class="icon-star-empty"></i>0</span>
<!--<span class="question-category"><a href="#"><i class="icon-folder-close"></i>CSS</a></span>
--><span class="question-date"><i class="icon-time"></i>15 secs ago</span>
<span class="question-comment"><a href="#"><i class="icon-comment"></i>5 Answers</a></span>
<a class="question-reply" href="#"><i class="icon-reply"></i>Reply</a>
<span class="question-view"><i class="icon-user"></i>70 views</span>
</div>
</div>
</article>
<article class="question user-question">
<h3>
<a href="single_question_private.php">This is my third Question</a>
</h3>
<div class="question-type-main"><i class="icon-question-sign"></i>Question</div>
<div class="question-content">
<div class="question-bottom">
<div class="question-answered question-answered-done"><i class="icon-ok"></i>solved</div>
<span class="question-favorite"><i class="icon-star-empty"></i>0</span>
<!--<span class="question-category"><a href="#"><i class="icon-folder-close"></i>HTML</a></span>
--><span class="question-date"><i class="icon-time"></i>15 secs ago</span>
<span class="question-comment"><a href="#"><i class="icon-comment"></i>5 Answers</a></span>
<a class="question-reply" href="#"><i class="icon-reply"></i>Reply</a>
<span class="question-view"><i class="icon-user"></i>70 views</span>
</div>
</div>
</article>
<article class="question user-question">
<h3>
<a href="single_question_private.php">This is my fourth Question</a>
</h3>
<div class="question-type-main"><i class="icon-question-sign"></i>Question</div>
<div class="question-content">
<div class="question-bottom">
<span class="question-favorite"><i class="icon-star-empty"></i>0</span>
<!--<span class="question-category"><a href="#"><i class="icon-folder-close"></i>PHP</a></span>
--><span class="question-date"><i class="icon-time"></i>15 secs ago</span>
<span class="question-comment"><a href="#"><i class="icon-comment"></i>5 Answers</a></span>
<a class="question-reply" href="#"><i class="icon-reply"></i>Reply</a>
<span class="question-view"><i class="icon-user"></i>70 views</span>
</div>
</div>
</article>
<article class="question user-question">
<h3>
<a href="single_question_private.php">This is my fifth Question</a>
</h3>
<div class="question-type-main"><i class="icon-question-sign"></i>Question</div>
<div class="question-content">
<div class="question-bottom">
<div class="question-answered"><i class="icon-ok"></i>in progress</div>
<span class="question-favorite"><i class="icon-star-empty"></i>0</span>
<!--<span class="question-category"><a href="#"><i class="icon-folder-close"></i>jQuery</a></span>
--><span class="question-date"><i class="icon-time"></i>15 secs ago</span>
<span class="question-comment"><a href="#"><i class="icon-comment"></i>5 Answers</a></span>
<a class="question-reply" href="#"><i class="icon-reply"></i>Reply</a>
<span class="question-view"><i class="icon-user"></i>70 views</span>
</div>
</div>
</article>
</div>
</div>
<div class="height_20"></div>
<div class="pagination">
<a href="#" class="prev-button"><i class="icon-angle-left"></i></a>
<span class="current">1</span>
<a href="#">2</a>
<a href="#">3</a>
<a href="#">4</a>
<a href="#">5</a>
<span>...</span>
<a href="#">11</a>
<a href="#">12</a>
<a href="#">13</a>
<a href="#" class="next-button"><i class="icon-angle-right"></i></a>
</div> 
 
</div> 



<aside class="col-md-3 sidebar">
<div class="widget widget_stats">
<h3 class="widget_title">Stats</h3>
<div class="ul_list ul_list-icon-ok">
<ul>
<li><i class="icon-question-sign"></i>Questions ( <span>20</span> )</li>
<li><i class="icon-comment"></i>Answers ( <span>50</span> )</li>
</ul>
</div>
</div>
<div class="widget widget_social">
<h3 class="widget_title">Find Us</h3>
<ul>
<li class="rss-subscribers">
<a href="#" target="_blank">
<strong>
<i class="icon-rss"></i>
<span>Subscribe</span><br>
<small>To RSS Feed</small>
</strong>
</a>
</li>
<li class="facebook-fans">
<a href="#" target="_blank">
<strong>
<i class="social_icon-facebook"></i>
<span>5,000</span><br>
<small>People like it</small>
</strong>
</a>
</li>
<li class="twitter-followers">
<a href="#" target="_blank">
<strong>
<i class="social_icon-twitter"></i>
<span>3,000</span><br>
<small>Followers</small>
</strong>
</a>
</li>
<li class="youtube-subs">
<a href="#" target="_blank">
<strong>
<i class="icon-play"></i>
<span>1,000</span><br>
<small>Subscribers</small>
</strong>
</a>
</li>
</ul>
</div>
<div class="widget widget_highest_points">
<h3 class="widget_title">Highest points</h3>
<ul>
<li>
<div class="author-img">
<a href="#"><img width="60" height="60" src="images/admin.jpeg" alt=""></a>
</div>
<h6><a href="#">admin</a></h6>
<span class="comment">12 Points</span>
</li>
<li>
<div class="author-img">
<a href="#"><img width="60" height="60" src="images/avatar.png" alt=""></a>
</div>
<h6><a href="#">vbegy</a></h6>
<span class="comment">10 Points</span>
</li>
<li>
<div class="author-img">
<a href="#"><img width="60" height="60" src="images/avatar.png" alt=""></a>
</div>
<h6><a href="#">ahmed</a></h6>
<span class="comment">5 Points</span>
</li>
</ul>
</div>
<div class="widget widget_tag_cloud">
<h3 class="widget_title">Tags</h3>
<a href="#">science</a>
<a href="#">computer</a>
<a href="#">art</a>
<a href="#">travel</a>
<a href="#">book</a>
<a href="#">jQuery</a>
<a href="#">bootstrap</a>
<a href="#">food</a>
</div>
</aside> 
</div> 
</section> 


<footer id="footer">
<section class="container">
<div class="row">
<div class="col-md-4">
<div class="widget widget_contact">
<h3 class="widget_title" >About Us</h3>
<p>We might not have answers of all our queries but the world has & we are here to connect you with them.</p>
<ul>
<!--<li>
<span>Address :</span>
C/O KUMAUN TENT HOUSE, COURT ROAD, JASPUR KHURD KASHIPUR
</li>-->
<li>
<span style="color:#fff">Support :</span>Phone No. : (+91) 9990035706
</li>
<li>Email : zapsartechnologies@gmail.com
</ul>
</div>
</div>
<div class="col-md-2">
<div class="widget">
<h3 class="widget_title">Quick Links</h3>
<ul>
<li><a href="index_private.php">Home</a></li>
<li><a href="cat_question_private.php">Category</a></li>
<li><a href="ask_question.php">Ask Question</a></li>
<li><a href="user_profile.php">View Profile</a></li>
<li><a href="edit_profile.php">Edit Profile</a></li>
<li><a href="user_questions.php">User Questions</a></li>
<li><a href="user_answers.php">User Answers</a></li>
<li><a href="user_favorite_questions.php">Favorite Questions</a></li>
<li><a href="user_points.php">User Points</a></li>
<li><a href="contact_us_private.php">About Us</a></li>
<li><a href="contact_us_private.php">Contact Us</a></li>
</ul>

</div>
</div>
<div class="col-md-3">
<div class="widget">
<h3 class="widget_title">Popular Questions</h3>
<ul class="related-posts">
<li class="related-item">
<h3><a href="#">This is my first Question</a></h3>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer lorem quam.</p>
<div class="clear"></div><span>Feb 22, 2014</span>
</li>
<li class="related-item">
<h3><a href="#">This Is My Second Poll Question</a></h3>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer lorem quam.</p>
<div class="clear"></div><span>Feb 22, 2014</span>
</li>
</ul>
</div>
</div>
<div class="col-md-3">
<div class="widget widget_twitter">
<h3 class="widget_title">Latest Tweets</h3>
<div class="tweet_1"></div>
</div>
</div>
</div> 
</section> 
</footer> 
<footer id="footer-bottom">
<section class="container">
<div class="copyrights f_left">Copyright &#169 2017 Zapsar</div>
<div class="social_icons f_right">
<ul>
<li class="twitter"><a original-title="Twitter" class="tooltip-n" href="#"><i class="social_icon-twitter font17"></i></a></li>
<li class="facebook"><a original-title="Facebook" class="tooltip-n" href="#"><i class="social_icon-facebook font17"></i></a></li>
<li class="gplus"><a original-title="Google plus" class="tooltip-n" href="#"><i class="social_icon-gplus font17"></i></a></li>
<li class="youtube"><a original-title="Youtube" class="tooltip-n" href="#"><i class="social_icon-youtube font17"></i></a></li>
<li class="skype"><a original-title="Skype" class="tooltip-n" href="skype:#?call"><i class="social_icon-skype font17"></i></a></li>
<li class="flickr"><a original-title="Flickr" class="tooltip-n" href="#"><i class="social_icon-flickr font17"></i></a></li>
<li class="rss"><a original-title="Rss" class="tooltip-n" href="#"><i class="social_icon-rss font17"></i></a></li>
</ul>
</div> 
</section> 
</footer> 
</div> 
<div class="go-up"><i class="icon-chevron-up"></i></div>
 
<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui-1.10.3.custom.min.js"></script>
<script src="js/jquery.easing.1.3.min.js"></script>
<script src="js/html5.js"></script>
<script src="js/twitter/jquery.tweet.js"></script>
<script src="js/jflickrfeed.min.js"></script>
<script src="js/jquery.inview.min.js"></script>
<script src="js/jquery.tipsy.js"></script>
<script src="js/tabs.js"></script>
<script src="js/jquery.flexslider.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>
<script src="js/jquery.carouFredSel-6.2.1-packed.js"></script>
<script src="js/jquery.scrollTo.js"></script>
<script src="js/jquery.nav.js"></script>
<script src="js/tags.js"></script>
<script src="js/jquery.bxslider.min.js"></script>
<script src="js/custom.js"></script>
 
</body>
</html>