<?php
include("get_qid.php");
session_start();

$uname=$_SESSION["auth_uname"];
$title=$_POST["question_title"];
$tags=$_POST["question_tags"];
$category=$_POST["question_category"];
//$attachment=$_POST["attachment_path"];
$details=$_POST["question_details"];

//echo "Uname:".$uname."|Title:".$title."|Tags:".$tags."|Category:".$category."|Details:".$details;

$con=mysql_connect("localhost","root","");
if(!$con){
echo "connection faiure";
}
else{
//echo "connection successful";
$db=mysql_query("use zapsar",$con);
if($db){
$rs=mysql_query("insert into qids values(null);",$con);
if($rs){
$qid="";
$res=mysql_query("select qid from qids order by qid DESC limit 1;",$con);
while($data=mysql_fetch_array($res)){
$qid=$data["qid"];
}
$rs=mysql_query("insert into questions_table values(null,'".$uname."',CONCAT('Q','".$qid."'),'".$title."','".$tags."','".$category."','".$details."','i',CONCAT(CURRENT_DATE,' ',CURRENT_TIME));",$con);
if($rs){

?>
<script type="text/javascript">
location.href="single_question_private.php";
</script>
<?php
mysql_close($con);
}else{
echo "failed to post question";
}
}
}

}



?>