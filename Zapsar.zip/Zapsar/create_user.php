<?php
$uname=$_POST["uname"];
$email=$_POST["email"];
$pswd=$_POST["pswd"];
$cpswd=$_POST["cpswd"];

if($pswd==$cpswd){
$con=mysql_connect("localhost","root","");
if(!$con){
echo "connection faiure";
}
else{
//echo "connection successful";
$db=mysql_query("use zapsar",$con);
if($db){
$rs=mysql_query("insert into user_creds values(null,'".$uname."','".$email."','".$pswd."',CONCAT(CURRENT_DATE,' ',CURRENT_TIME));",$con);
if($rs){
?>
<script type="text/javascript">
location.href="index.php";
</script>
<?php
mysql_close($con);
}else{
echo "failed to create user account";
}
}
}
}
?>