<?php
$uname=$_POST["uname"];
$pswd=$_POST["pswd"];

$con=mysql_connect("localhost","root","");
if(!$con){
echo "connection faiure";
}
else{
//echo "connection successful";
$db=mysql_query("use zapsar",$con);
if($db){
$rs=mysql_query("select pswd from user_creds where username='".$uname."' ;",$con);
while($data=mysql_fetch_array($rs)){
if($data["pswd"]==$pswd){
session_start();
$_SESSION["auth_uname"]=$uname;
?>
<script type="text/javascript">
location.href="index_private.php";
</script>
<?php
mysql_close($con);
}
else{
echo "User/ Password Didn't match";
}
}
}
}
?>
