<?php

function get_qid(){
$connect=mysql_connect("localhost","root","");
if(!$connect){
echo "connection faiure";
}
else{
echo "connection successful";
$db=mysql_query("use zapsar",$connect);
if($db){
$rs=mysql_query("insert into qids values(null);",$connect);
if($rs){
$res=mysql_query("select qid from qids order by qid DESC limit 1;",$connect);
while($data=mysql_fetch_array($res)){
$qid=$data["qid"];
mysql_close($connect);
return $qid;
}
}
}
}
}



?>