<?php
session_start();
$uname=$_SESSION["auth_uname"];
$fname=$_POST["fname"];
$lname=$_POST["lname"];
$website=$_POST["website"];
$country=$_POST["country"];
$picture=$_POST["picture"];
$about_me=$_POST["about_me"];
$facebook_link=$_POST["facebook_link"];
$twitter_link=$_POST["twitter_link"];
$linkedin_link=$_POST["linkedin_link"];
$googleplus_link=$_POST["googleplus_link"];
$curr_pswd=$_POST["curr_pswd"];
$new_pswd=$_POST["new_pswd"];
$confirm_pswd=$_POST["confirm_pswd"];

$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
echo "connection faiure";
}
else{
$rs=mysqli_query($con,"insert into user_creds values(null,'".$uname."','".$email."','".$pswd."',CONCAT(CURRENT_DATE,' ',CURRENT_TIME));");
if($rs){
?>
<script type="text/javascript">
location.href="user_profile.php";
</script>
<?php
mysqli_close($con);
}else{
echo "failed to failed to update user profile";
}
}
}
?>