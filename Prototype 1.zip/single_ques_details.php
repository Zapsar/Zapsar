<?php

$q_id=$_SESSION["single_ques_id"];
$q_title=$title;
$q_details=$details;
$q_author=$author;
$q_tags=$tags;
$q_category=$category;
$q_status=$status;
$q_views=$views;
$q_post_date=$post_date;


?>