<?php
include("creds.php");

$uname=$_POST["uname"];
$email=$_POST["email"];
$pswd=$_POST["pswd"];
$cpswd=$_POST["cpswd"];

if($pswd==$cpswd){
$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
?>
<script type="text/javascript">
location.href="index.php";
alert("We're having some problem with our servers.");
</script>
<?php
}
else{
//echo "connection successful";
$rs=mysqli_query($con,"insert into user_creds values(null,'".$uname."','".$email."','".$pswd."',CONCAT(CURRENT_DATE,' ',CURRENT_TIME));");
if($rs){
?>
<script type="text/javascript">
location.href="index.php";
alert("New Account Created. Login to access your account.");

</script>
<?php
mysqli_close($con);
}else{
?>
<script type="text/javascript">
location.href="index.php";
alert("SORRY, we are not able create your account.");
</script>
<?php
}

}
}
?>