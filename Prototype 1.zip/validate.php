<?php
include("creds.php");

$uname=$_POST["uname"];
$pswd=$_POST["pswd"];
if($uname=="Username"||$pswd=="Password"){
?>
<script type="text/javascript">
location.href="index.php";
alert("Username or Password filed are empty.");
</script>
<?php
}else{
$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
?>
<script type="text/javascript">
location.href="index.php";
alert("We're having some problem with our servers.");
</script>
<?php
}
else{
//echo "connection successful";
if($rs=mysqli_query($con,"select pswd from user_creds where username='".$uname."' ;")){

if(mysqli_num_rows($rs)>0){

while($data=mysqli_fetch_array($rs,MYSQLI_ASSOC)){
if($data["pswd"]==$pswd){
mysqli_close($con);
session_start();
$_SESSION["auth_uname"]=$uname;
?>
<script type="text/javascript">
location.href="index_private.php";
</script>
<?php
}
else{
redirect($con);
}
}
}
else{
redirect($con);
}
}else{
redirect($con);
}
}
}
?>

<?php
function redirect($con){
mysqli_close($con);
?>
<script type="text/javascript">
location.href="index.php";
alert("Username or Password incorrect.");
</script>
<?php

}
?>
