<?php
$mysql_host="localhost";
$mysql_user="root";
$mysql_password="";
$mysql_port="3306";
$mysql_db="zapsar";
?>