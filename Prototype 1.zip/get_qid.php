<?php
include("creds.php");

function get_qid(){
$connect=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($connect->connect_error){
echo "connection faiure";
}
else{
echo "connection successful";
$rs=mysqli_query($connect,"insert into qids values(null);");
if($rs){
$res=mysqli_query($connect,"select qid from qids order by qid DESC limit 1;");
while($data=mysqli_fetch_array($res,MYSQLI_ASSOC)){
$qid=$data["qid"];
mysqli_close($connect);
return $qid;
}

}
}
}



?>