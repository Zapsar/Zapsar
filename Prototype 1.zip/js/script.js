function enable_pswd_fields(){
if(document.getElementById("change_pswd_chk").checked==true){
document.getElementById("pswd_field1").disabled=false;
document.getElementById("pswd_field2").disabled=false;
document.getElementById("pswd_field3").disabled=false;
document.getElementById("pswd_field1").style.background="#f3f3f3";
document.getElementById("pswd_field2").style.background="#f3f3f3";
document.getElementById("pswd_field3").style.background="#f3f3f3";
}else
if(document.getElementById("change_pswd_chk").checked==false){
document.getElementById("pswd_field1").disabled=true;
document.getElementById("pswd_field2").disabled=true;
document.getElementById("pswd_field3").disabled=true;
document.getElementById("pswd_field1").style.background="#e1e1e1";
document.getElementById("pswd_field2").style.background="#e1e1e1";
document.getElementById("pswd_field3").style.background="#e1e1e1";
}

}

function validate_login(){
var uname=document.getElementById("uname").value;
var pswd=document.getElementById("pswd").value;
if(uname=""&&pswd=""){
alert("Username & Password fields are empty.");
}else if(uname=""){
alert("Username field empty.");
}else if(pswd=""){
alert("Password field empty.");
}else{
document.getElementById("login_form").action="validate.php";
}
}
