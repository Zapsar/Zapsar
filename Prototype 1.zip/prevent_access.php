<?php
session_start();
$uname=$_SESSION["auth_uname"];
if($uname==""){
?>
<script type="text/javascript">
location.href="index.php";
</script>
<?php 
}

?>
