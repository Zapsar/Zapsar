<?php
include("get_qid.php");
include("creds.php");

session_start();

$uname=$_SESSION["auth_uname"];
$title=$_POST["question_title"];
$tags=$_POST["question_tags"];
$category=$_POST["question_category"];
//$attachment=$_POST["attachment_path"];
$details=$_POST["question_details"];

//echo "Uname:".$uname."|Title:".$title."|Tags:".$tags."|Category:".$category."|Details:".$details;

$con=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$mysql_db,$mysql_port);
if($con->connect_error){
?>
<script type="text/javascript">
location.href="ask_question.php";
alert("We're having some problem with our servers.");
</script>
<?php
}
else{
//echo "connection successful";
$rs=mysqli_query($con,"insert into qids values(null);");
if($rs){
$qid="";
$res=mysqli_query($con,"select qid from qids order by qid DESC limit 1;");
while($data=mysqli_fetch_array($res,MYSQLI_ASSOC)){
$qid=$data["qid"];
}
$rs=mysqli_query($con,"insert into questions_table values(null,'".$uname."',CONCAT('Q','".$qid."'),'".$title."','".$tags."','".$category."','".$details."','i',CONCAT(CURRENT_DATE,' ',CURRENT_TIME));");
if($rs){
$_SESSION["single_ques_id"]=$qid;
$_SESSION["single_ques_title"]=$title;
$_SESSION["single_ques_details"]=$details;
$_SESSION["single_ques_status"]='i';
$_SESSION["single_ques_views"]=0;
$_SESSION["single_ques_tags"]=$tags;
$_SESSION["single_ques_category"]=$category;
$_SESSION["single_ques_post_date"]='';
$_SESSION["single_ques_author"]=$uname;
$_SESSION["single_ques_stars"]=2;
$_SESSION["single_ques_answers"]=0;
?>
<script type="text/javascript">
location.href="single_question_private.php";
alert("GREAT!, Your question publised successfully.");
</script>
<?php
mysqli_close($con);
}else{
?>
<script type="text/javascript">
location.href="ask_question.php";
alert("SORRY, not able to publish your question. Please Try again...");
</script>
<?php
}
}


}



?>