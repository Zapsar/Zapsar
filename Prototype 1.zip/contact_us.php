﻿<!DOCTYPE html>
<html lang="en">
<head>
 
<meta charset="utf-8">
<title>Zapsar – We Have Answers</title>
<meta name="description" content="Zapsar We Have Answers">
<meta name="author" content="abhi@tech">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="css/skins.css">
<link rel="stylesheet" href="css/responsive.css">
 
<link rel="shortcut icon" href="images/favicon.png">

<!--Pre Color:#ff7361-->
<style>
a {
    text-decoration: none;
}

a:hover {
    text-decoration: none;
}

a:focus {
    text-decoration: none;
}

</style>
</head>

<body>

<div class="loader"><div class="loader_html"></div></div>
<div id="wrap" class="grid_1200">
<!-------------------------------   Header       -------------------------------------->
<header id="header" style="background:#34dddd" class=""  >
<!--<div data-spy="affix" data-offset-top="160">
<div class="navbar navbar-default navbar-fixed-top" role="navigation" style="background-color:#34dddd">
-->
<section class="container clearfix" >
<div class="logo"><a href="index.php"><img alt="" src="images/logo.png"></a></div>
<nav class="navigation"  >
<ul class="">
<li class="current_page_item"><a href="index.php">Home</a></li>

<li><a href="cat_question.php">Category</a>
<ul>
<li><a href="cat_question.php">Arts</a></li>
<li><a href="cat_question.php">Books</a></li>
<li><a href="cat_question.php">Business</a></li>
<li><a href="cat_question.php">Cooking</a></li>
<li><a href="cat_question.php">Fitness</a></li>
<li><a href="cat_question.php">Finance</a></li>
<li><a href="cat_question.php">Food</a></li>
<li><a href="cat_question.php">Science</a></li>
<li><a href="cat_question.php">Technology</a></li>
</ul>
</li>

<li><a href="contact_us.php">Contact Us</a></li>
<li><a href="#" id="login-panel">Login</a></li>
</ul>
</nav>
</section> 
<!--</div>
</div>-->
</header> 

<!------------------------------------- Login Panel     ------------------------------------->
<div class="login-panel" style="background-color:#f3f3f3">
<section class="container">
<div class="row" >
<div class="col-md-6">
<div class="page-content">
<h2>Login</h2>
<div class="form-style form-style-3">
<form action="index_private.php">
<div class="form-inputs clearfix">
<p class="login-text">
<input type="text" value="Username" onfocus="if (this.value == 'Username') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Username';}">
<i class="icon-user"></i>
</p>
<p class="login-password">
<input type="password" value="Password" onfocus="if (this.value == 'Password') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Password';}">
<i class="icon-lock"></i>
<a href="#">Forget</a>
</p>
</div>
<p class="form-submit login-submit">
<input type="submit" value="Log in" class="button color small login-submit submit">
</p>
<div class="rememberme">
<label style="color:#000;"><input type="checkbox" checked="checked"> Remember Me</label>
</div>
</form>
</div>
</div> 
</div>
 
<div class="col-md-6">
<div class="page-content Register">
<h2>Register Now</h2>
<p style="color:#000;">Don't have an account, create a new one here...</p>
<a class="button color small signup">Create an account</a>
</div> 
</div> 
</div>
</section>
</div> 
<div class="panel-pop" id="signup">
<h2>Register Now<i class="icon-remove"></i></h2>
<div class="form-style form-style-3">
<form>
<div class="form-inputs clearfix">
<p>
<label class="required">Username<span>*</span></label>
<input type="text">
</p>
<p>
<label class="required">E-Mail<span>*</span></label>
<input type="email">
</p>
<p>
<label class="required">Password<span>*</span></label>
<input type="password" value="">
</p>
<p>
<label class="required">Confirm Password<span>*</span></label>
<input type="password" value="">
</p>
</div>
<p class="form-submit">
<input type="submit" value="Signup" class="button color small submit">
</p>
</form>
</div>
</div> 
<div class="panel-pop" id="lost-password">
<h2>Forget Password<i class="icon-remove"></i></h2>
<div class="form-style form-style-3" >
<p>Please enter your username and email address. You will receive a link to create a new password via email.</p>
<form>
<div class="form-inputs clearfix">
<p>
<label class="required">Username<span>*</span></label>
<input type="text">
</p>
<p>
<label class="required">E-Mail<span>*</span></label>
<input type="email">
</p>
</div>
<p class="form-submit">
<input type="submit" value="Reset" class="button color small submit">
</p>
</form>
<div class="clearfix"></div>
</div>
</div> 

<div class="breadcrumbs">
<section class="container">
<div class="row">
<div class="col-md-12">
<h1>Contact Us</h1>
</div>
<div class="col-md-12">
<div class="crumbs">
<a href="index.php">Home</a>
<span class="crumbs-span">/</span>
<span class="current">Contact Us</span>
</div>
</div>
</div> 
</section> 
</div> 
<section class="container main-content page-full-width">
<div class="row">
<div class="contact-us">
<div class="col-md-7">
<div class="page-content">
<h2>We would love to listen to you</h2>
<p>If you have any queries or ideas, don't hesitate to write us</p>
<form class="form-style form-style-3 form-style-5 form-js" action="contact_us.php" method="post">
<div class="form-inputs clearfix">
<p>
<label for="name" class="required">Name<span>*</span></label>
<input type="text" class="required-item" value="" name="name" id="name" aria-required="true">
</p>
<p>
<label for="mail" class="required">E-Mail<span>*</span></label>
<input type="email" class="required-item" id="mail" name="mail" value="" aria-required="true">
</p>
<p>
<label for="url" class="required">Subject<span>*</span></label>
<input type="text" id="url" name="url" value="">
</p>
</div>
<div class="form-textarea">
<p>
<label for="message" class="required">Message<span>*</span></label>
<textarea id="message" class="required-item" name="message" aria-required="true" cols="58" rows="7"></textarea>
</p>
</div>
<p class="form-submit">
<input name="submit" type="submit" value="Send" class="submit button small color">
</p>
</form>
</div> 
</div> 
<div class="col-md-5">
<div class="page-content">
<h2>About Us</h2>
<p>We might not have answers of all our queries but the world has and we are here to connect you with them.</p>
<div class="widget widget_contact">
<ul>
<li><i class="icon-map-marker"></i>Address :<p>C/O KUMAUN TENT HOUSE, COURT ROAD, JASPUR KHURD KASHIPUR, UTTARAKHAND (244713)
</p></li>
<li><i class="icon-phone"></i>Phone number :<p>(+91) 9990035706</p></li>
<li><i class="icon-envelope-alt"></i>E-mail :<p>zapsartechnoloies@gmail.com</p></li>
<li>
<i class="icon-share"></i>Social links :
<p>
<a href="#" original-title="Facebook" class="tooltip-n">
<span class="icon_i">
<span class="icon_square" icon_size="25" span_bg="#3b5997" span_hover="#2f3239">
<i i_color="#FFF" class="social_icon-facebook"></i>
</span>
</span>
</a>
<a href="#" original-title="Twitter" class="tooltip-n">
<span class="icon_i">
<span class="icon_square" icon_size="25" span_bg="#00baf0" span_hover="#2f3239">
<i i_color="#FFF" class="social_icon-twitter"></i>
</span>
</span>
</a>
<a original-title="Youtube" class="tooltip-n" href="#">
<span class="icon_i">
<span class="icon_square" icon_size="25" span_bg="#cc291f" span_hover="#2f3239">
<i i_color="#FFF" class="social_icon-youtube"></i>
</span>
</span>
</a>
<a href="#" original-title="Linkedin" class="tooltip-n">
<span class="icon_i">
<span class="icon_square" icon_size="25" span_bg="#006599" span_hover="#2f3239">
<i i_color="#FFF" class="social_icon-linkedin"></i>
</span>
</span>
</a>
<a href="#" original-title="Google plus" class="tooltip-n">
<span class="icon_i">
<span class="icon_square" icon_size="25" span_bg="#ca2c24" span_hover="#2f3239">
<i i_color="#FFF" class="social_icon-gplus"></i>
</span>
</span>
</a>
<a original-title="RSS" class="tooltip-n" href="#">
<span class="icon_i">
<span class="icon_square" icon_size="25" span_bg="#F18425" span_hover="#2f3239">
<i i_color="#FFF" class="icon-rss"></i>
</span>
</span>
</a>
<a original-title="Instagram" class="tooltip-n" href="#">
<span class="icon_i">
<span class="icon_square" icon_size="25" span_bg="#306096" span_hover="#2f3239">
<i i_color="#FFF" class="social_icon-instagram"></i>
</span>
</span>
</a>
<a original-title="Dribbble" class="tooltip-n" href="#">
<span class="icon_i">
<span class="icon_square" icon_size="25" span_bg="#e64281" span_hover="#2f3239">
<i i_color="#FFF" class="social_icon-dribbble"></i>
</span>
</span>
</a>
<a original-title="Pinterest" class="tooltip-n" href="#">
<span class="icon_i">
<span class="icon_square" icon_size="25" span_bg="#c7151a" span_hover="#2f3239">
<i i_color="#FFF" class="icon-pinterest"></i>
</span>
</span>
</a>
</p>
</li>
</ul>
</div>
</div> 
</div> 
</div> 
</div> 
</section> 
 
<footer id="footer">
<section class="container">
<div class="row">
<div class="col-md-4">
<div class="widget widget_contact">
<h3 class="widget_title" >About Us</h3>
<p>We might not have answers of all our queries but the world has & we are here to connect you with them.</p>
<ul>
<!--<li>
<span>Address :</span>
C/O KUMAUN TENT HOUSE, COURT ROAD, JASPUR KHURD KASHIPUR
</li>-->
<li>
<span style="color:#fff">Support :</span>Phone No. : (+91) 9990035706
</li>
<li>Email : zapsartechnologies@gmail.com</li>
</ul>
</div>
</div>
<div class="col-md-2">
<div class="widget">
<h3 class="widget_title">Quick Links</h3>
<ul>
<li><a href="index.php">Home</a></li>
<li><a href="cat_question.php">Category</a></li>
<li><a href="contact_us.php">About</a></li>
<li><a href="contact_us.php">Contact Us</a></li>
</ul>
</div>
</div>
<div class="col-md-3">
<div class="widget">
<h3 class="widget_title">Popular Questions</h3>
<ul class="related-posts">
<li class="related-item">
<h3><a href="#">This is my first Question</a></h3>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer lorem quam.</p>
<div class="clear"></div><span>Feb 22, 2014</span>
</li>
<li class="related-item">
<h3><a href="#">This Is My Second Poll Question</a></h3>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer lorem quam.</p>
<div class="clear"></div><span>Feb 22, 2014</span>
</li>
</ul>
</div>
</div>
<div class="col-md-3">
<div class="widget widget_twitter">
<h3 class="widget_title">Latest Tweets</h3>
<div class="tweet_1"></div>
</div>
</div>
</div> 
</section> 
</footer> 
<footer id="footer-bottom">
<section class="container">
<div class="copyrights f_left">Copyright &#169 2017 Zapsar</div>
<div class="social_icons f_right">
<ul>
<li class="twitter"><a original-title="Twitter" class="tooltip-n" href="#"><i class="social_icon-twitter font17"></i></a></li>
<li class="facebook"><a original-title="Facebook" class="tooltip-n" href="#"><i class="social_icon-facebook font17"></i></a></li>
<li class="gplus"><a original-title="Google plus" class="tooltip-n" href="#"><i class="social_icon-gplus font17"></i></a></li>
<li class="youtube"><a original-title="Youtube" class="tooltip-n" href="#"><i class="social_icon-youtube font17"></i></a></li>
<li class="skype"><a original-title="Skype" class="tooltip-n" href="skype:#?call"><i class="social_icon-skype font17"></i></a></li>
<li class="flickr"><a original-title="Flickr" class="tooltip-n" href="#"><i class="social_icon-flickr font17"></i></a></li>
<li class="rss"><a original-title="Rss" class="tooltip-n" href="#"><i class="social_icon-rss font17"></i></a></li>
</ul>
</div> 
</section> 
</footer> 
</div> 
<div class="go-up"><i class="icon-chevron-up"></i></div>
 
<script src="js/jquery.min.js"></script>
<script src="js/jquery-ui-1.10.3.custom.min.js"></script>
<script src="js/jquery.easing.1.3.min.js"></script>
<script src="js/html5.js"></script>
<script src="js/jquery.tweet.js"></script>
<script src="js/jflickrfeed.min.js"></script>
<script src="js/jquery.inview.min.js"></script>
<script src="js/jquery.tipsy.js"></script>
<script src="js/tabs.js"></script>
<script src="js/jquery.flexslider.js"></script>
<script src="js/jquery.prettyPhoto.js"></script>
<script src="js/jquery.carouFredSel-6.2.1-packed.js"></script>
<script src="js/jquery.scrollTo.js"></script>
<script src="js/jquery.nav.js"></script>
<script src="js/tags.js"></script>
<script src="js/jquery.bxslider.min.js"></script>
<script src="js/custom.js"></script>
 
</body>
</html>